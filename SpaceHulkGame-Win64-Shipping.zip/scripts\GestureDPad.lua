local vr = uevr.params.vr
local params = uevr.params
local callbacks = params.sdk.callbacks

-- ============================================================
-- Set DEBUG = true to log button bits + activation state.
-- NOTE: plain print() does NOT reach the UEVR log; logging must
-- go through params.functions.log_info (see logmsg below).
-- ============================================================
local DEBUG = false

local function logmsg(msg)
    pcall(function()
        if params.functions and params.functions.log_info then
            params.functions.log_info("[GDP] " .. msg)
        end
    end)
end

local BUMP_DURATION  = 0.05
local BUMP_FREQUENCY = 1000.0
local BUMP_AMPLITUDE = 1.0
local DOUBLE_GAP     = 0.13

-- Activation touch bump: lighter + shorter than the confirm bump
local TOUCH_BUMP_DURATION  = 0.02
local TOUCH_BUMP_AMPLITUDE = 0.5

local travelThreshold = 0.10

local XINPUT_DPAD_UP      = 0x0001
local XINPUT_DPAD_DOWN    = 0x0002
local XINPUT_DPAD_LEFT    = 0x0004
local XINPUT_DPAD_RIGHT   = 0x0008
local XINPUT_GAMEPAD_BACK = 0x0020   -- Xbox "View"
local XINPUT_GAMEPAD_RB   = 0x0200   -- Right shoulder

-- Source handles are fetched FRESH on every use, never cached at load time.
-- Caching at file scope yields stale/invalid handles because scripts load
-- before the VR runtime has controllers fully initialized.
local function rightSrc() return vr.get_right_joystick_source() end
local function leftSrc()  return vr.get_left_joystick_source()  end

local thumbrestAction     = vr.get_action_handle("/actions/default/in/ThumbrestTouchRight")
local leftThumbrestAction = vr.get_action_handle("/actions/default/in/ThumbrestTouchLeft")

local RightHandPos = UEVR_Vector3f.new()
local RightHandRot = UEVR_Quaternionf.new()
local RH_Local     = UEVR_Vector3f.new()

local H_Pos = UEVR_Vector3f.new()
local H_Rot = UEVR_Quaternionf.new()

local q_tmp1 = UEVR_Quaternionf.new()
local q_tmp2 = UEVR_Quaternionf.new()
local q_v    = UEVR_Quaternionf.new()

-- gesture-start snapshot
local startWorldX, startWorldY, startWorldZ = 0.0, 0.0, 0.0
local StartHeadRot = UEVR_Quaternionf.new()

-- ============================================================
-- Math
-- ============================================================
local function quat_conj(q, out)
    out.x, out.y, out.z, out.w = -q.x, -q.y, -q.z, q.w
    return out
end

local function quat_mul(a, b, out)
    local ax, ay, az, aw = a.x, a.y, a.z, a.w
    local bx, by, bz, bw = b.x, b.y, b.z, b.w
    out.x = aw*bx + ax*bw + ay*bz - az*by
    out.y = aw*by - ax*bz + ay*bw + az*bx
    out.z = aw*bz + ax*by - ay*bx + az*bw
    out.w = aw*bw - ax*bx - ay*by - az*bz
    return out
end

-- world displacement -> frame described by quaternion q
local function world_delta_to_frame(dx, dy, dz, q, out_vec3)
    q_v.x, q_v.y, q_v.z, q_v.w = dx, dy, dz, 0
    quat_conj(q, q_tmp1)
    quat_mul(q_tmp1, q_v, q_tmp2)
    quat_mul(q_tmp2, q, q_tmp1)
    out_vec3.x, out_vec3.y, out_vec3.z = q_tmp1.x, q_tmp1.y, q_tmp1.z
    return out_vec3
end

local function get_hmd_pose(posOut, rotOut)
    if vr.get_pose and vr.get_hmd_index then
        local ok, idx = pcall(vr.get_hmd_index)
        if ok and idx ~= nil then
            local ok2 = pcall(vr.get_pose, idx, posOut, rotOut)
            if ok2 then return true end
        end
    end
    posOut.x, posOut.y, posOut.z = 0, 0, 0
    rotOut.x, rotOut.y, rotOut.z, rotOut.w = 0, 0, 0, 1
    return false
end

-- ============================================================
-- Haptics
-- ============================================================
local current_time = 0.0
local haptic_events = {}

local function stage_single_bump(controller, delay, duration, amp, freq)
    local evt = {
        time     = current_time + (delay or 0.0),
        duration = duration or BUMP_DURATION,
        freq     = freq or BUMP_FREQUENCY,
        amp      = amp or BUMP_AMPLITUDE,
        controller = controller
    }
    -- insert time-ordered so a delayed bump cannot block an immediate one
    local i = #haptic_events
    while i > 0 and haptic_events[i].time > evt.time do
        haptic_events[i + 1] = haptic_events[i]
        i = i - 1
    end
    haptic_events[i + 1] = evt
end

local function stage_touch_bump(controller)
    stage_single_bump(controller, 0.0, TOUCH_BUMP_DURATION, TOUCH_BUMP_AMPLITUDE)
end

local function process_haptic_queue()
    -- drain every event that is due, not just one per tick
    while #haptic_events > 0 and current_time >= haptic_events[1].time do
        local evt = table.remove(haptic_events, 1)
        pcall(vr.trigger_haptic_vibration, 0.0, evt.duration, evt.freq, evt.amp, evt.controller)
    end
end

-- ============================================================
-- State
-- ============================================================
local rb_held         = false   -- latched in on_xinput_get_state
local rb_seen         = false   -- has the callback ever fired?
local gesture_active  = false   -- thumbrest OR rb  (THE activation flag)
local was_active      = false
local left_thumb_down = false
local left_was_down   = false
local triggered       = false
local deltaX, deltaY  = 0, 0

local dbg_last_btns = nil
local dbg_last_act  = nil

-- ============================================================
-- Tick
-- ============================================================
callbacks.on_pre_engine_tick(function(engine, delta)
    current_time = current_time + delta

    -- ---- activation: right thumbrest OR RB ----
    local RightHandle = rightSrc()
    local LeftHandle  = leftSrc()

    local thumbrest_active = false
    if RightHandle and thumbrestAction then
        local ok, r = pcall(vr.is_action_active, thumbrestAction, RightHandle)
        thumbrest_active = (ok and r) and true or false
    end

    -- RB: latched value if the callback has fired, else poll as fallback
    local rb_now = rb_held
    if not rb_seen and params.sdk.get_xinput_state then
        local ok, st = pcall(params.sdk.get_xinput_state, 0)
        if ok and st and st.Gamepad then
            rb_now = ((st.Gamepad.wButtons & XINPUT_GAMEPAD_RB) ~= 0)
        end
    end

    gesture_active = thumbrest_active or rb_now

    if DEBUG and gesture_active ~= dbg_last_act then
        logmsg(string.format("active=%s  (thumbrest=%s  rb=%s  rb_seen=%s)",
            tostring(gesture_active), tostring(thumbrest_active),
            tostring(rb_now), tostring(rb_seen)))
        dbg_last_act = gesture_active
    end

    -- ---- left thumbrest ----
    left_thumb_down = false
    if leftThumbrestAction then
        if vr.is_action_active_any_joystick then
            local ok, r = pcall(vr.is_action_active_any_joystick, leftThumbrestAction)
            if ok and r then left_thumb_down = true end
        end
        if not left_thumb_down and LeftHandle then
            local ok2, r2 = pcall(vr.is_action_active, leftThumbrestAction, LeftHandle)
            if ok2 and r2 then left_thumb_down = true end
        end
    end

    if left_thumb_down and not left_was_down then
        stage_touch_bump(LeftHandle)
    end
    left_was_down = left_thumb_down

    -- ---- controller pose ----
    pcall(vr.get_pose, vr.get_right_controller_index(), RightHandPos, RightHandRot)

    -- ---- gesture start / end ----
    if gesture_active and not was_active then
        get_hmd_pose(H_Pos, H_Rot)
        StartHeadRot.x, StartHeadRot.y = H_Rot.x, H_Rot.y
        StartHeadRot.z, StartHeadRot.w = H_Rot.z, H_Rot.w

        startWorldX = RightHandPos.x
        startWorldY = RightHandPos.y
        startWorldZ = RightHandPos.z

        triggered = false
        stage_touch_bump(RightHandle)
    elseif not gesture_active and was_active then
        triggered = false
    end

    -- ---- delta in frozen frame ----
    if gesture_active and not triggered then
        local wdx = RightHandPos.x - startWorldX
        local wdy = RightHandPos.y - startWorldY
        local wdz = RightHandPos.z - startWorldZ
        world_delta_to_frame(wdx, wdy, wdz, StartHeadRot, RH_Local)
        deltaX = RH_Local.x
        deltaY = RH_Local.y
    else
        deltaX, deltaY = 0, 0
    end

    was_active = gesture_active

    process_haptic_queue()
end)

-- ============================================================
-- XInput
-- ============================================================
callbacks.on_xinput_get_state(function(retval, user_index, state)
    -- Only act on pad 0. Games poll all four slots; empty slots 1-3 return
    -- zeroed state, which would clobber rb_held and misdirect injection.
    if user_index ~= 0 then return end
    if not state or not state.Gamepad then return end

    local btns = state.Gamepad.wButtons

    -- latch RB from the real gamepad state
    rb_seen = true
    rb_held = ((btns & XINPUT_GAMEPAD_RB) ~= 0)

    if DEBUG and btns ~= dbg_last_btns then
        logmsg(string.format("wButtons = 0x%04X   RB(0x0200)=%s",
            btns, tostring(rb_held)))
        dbg_last_btns = btns
    end

    -- left thumbrest = View, while gesture is armed
    if gesture_active and left_thumb_down then
        state.Gamepad.wButtons = state.Gamepad.wButtons | XINPUT_GAMEPAD_BACK
    end

    if triggered or not gesture_active then return end

    local absX = (deltaX >= 0) and deltaX or -deltaX
    local absY = (deltaY >= 0) and deltaY or -deltaY

    if absX >= travelThreshold or absY >= travelThreshold then
        triggered = true

        local RH = rightSrc()

        if absX > absY then
            if deltaX > 0 then
                state.Gamepad.wButtons = state.Gamepad.wButtons | XINPUT_DPAD_RIGHT
                stage_single_bump(RH, 0.0)
                stage_single_bump(RH, DOUBLE_GAP)
            else
                state.Gamepad.wButtons = state.Gamepad.wButtons | XINPUT_DPAD_LEFT
                stage_single_bump(RH, 0.0)
            end
        else
            if deltaY > 0 then
                state.Gamepad.wButtons = state.Gamepad.wButtons | XINPUT_DPAD_UP
                stage_single_bump(RH, 0.0)
            else
                state.Gamepad.wButtons = state.Gamepad.wButtons | XINPUT_DPAD_DOWN
                stage_single_bump(RH, 0.0)
            end
        end

        if DEBUG then
            logmsg(string.format("FIRED  dX=%.4f dY=%.4f", deltaX, deltaY))
        end
    end
end)

logmsg("GestureDPad loaded  (DEBUG=" .. tostring(DEBUG) .. ")")