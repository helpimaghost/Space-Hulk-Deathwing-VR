--[[
    UIPeek.lua  (v3 -- consolidated)
    -----------------------------------------------------------------
    Single peek trigger (right thumbrest touch, optionally RB) now
    drives THREE things at once:

      1. UEVR UI panel      -- UI_Distance pushed to 0.5 (hidden) /
                               restored to 2.875 (visible)   [v2 behaviour]
      2. Game HUD widgets   -- every screen-space UMG WidgetComponent
                               hidden by default, shown while engaged
                               [absorbed from HUDPeek.lua]
      3. Ammo counter       -- same treatment, tracked separately so it
                               can be split off later
                               [absorbed from AmmoCounterUI.lua]

    NOTE ON OVERLAP: the ammo counter IS a screen-space WidgetComponent,
    so the HUD sweep would catch it anyway. It is classified separately
    only so you can give it its own hide mode / trigger / exclusion
    without touching the rest of the HUD. Set MANAGE_AMMO = false and it
    falls back into the generic HUD group.

    -----------------------------------------------------------------
    HIDE MODES  (per group, see CONFIG)

    "visibility"  -- reads the hosted UUserWidget's Visibility byte,
                     caches it, then calls SetVisibility(Collapsed).
                     Restore writes the cached value back.
                     Non-destructive: the component keeps its Widget
                     reference the whole time, so there is no dangling
                     pointer and no re-init cycle. This is the default.

    "detach"      -- the old HUDPeek behaviour: SetWidget(nil) to hide,
                     SetWidget(cachedWidget) to restore.
                     RISK: once detached, the component is usually the
                     only strong reference to that UUserWidget, so it
                     can be garbage collected between hide and restore.
                     Pushing a collected pointer back in will crash.
                     Also, SetWidget(w) is one half of the nil->w re-init
                     cycle that previously stole input focus. Use only if
                     "visibility" turns out not to take on this build.

    If SetVisibility is missing on a widget, that entry auto-falls back
    to "detach" and says so in the log.

    -----------------------------------------------------------------
    DUMP VERIFICATION REQUIRED before trusting "visibility" mode.
    Confirm these exist in object_dump_1.txt:

      Select-String -Path object_dump_1.txt -Pattern "UMG.Widget.SetVisibility"
      Select-String -Path object_dump_1.txt -Pattern "ESlateVisibility"

    ESlateVisibility byte values assumed below:
      0 Visible | 1 Collapsed | 2 Hidden | 3 HitTestInvisible
      4 SelfHitTestInvisible
    If the dump orders them differently, fix VIS_COLLAPSED.

    -----------------------------------------------------------------
    SAFETY RULE KEPT FROM HUDPeek: only Space == 1 (screen space)
    components are ever touched. World-space widgets render through
    UEVR's stereo hook; mutating them mid-render is what produced the
    FFakeStereoRenderingHook null-pointer crash.

    Getter uses colon syntax (vr:get_mod_value), setter uses dot
    (vr.set_mod_value). set_mod_value takes STRINGS, not Lua numbers.

    PLACEMENT: scripts\ ROOT (next to MainHandler.lua) so it auto-runs.
--]]

local vr        = uevr.params.vr
local params    = uevr.params
local callbacks = params.sdk.callbacks

------------------------------------------------------------------
-- CONFIG
------------------------------------------------------------------
-- Trigger
local USE_THUMBREST     = true          -- right thumbrest touch engages peek
local USE_RB            = true          -- right bumper hold engages peek

-- Per-trigger release grace. When more than one trigger is active the
-- LONGEST grace wins, so letting go of the thumbrest while still holding RB
-- does not cut the peek short. Set any to 0 for an instant drop.
local RELEASE_GRACE_THUMBREST = 0.25    -- touch is twitchy, needs the buffer
local RELEASE_GRACE_RB        = 0.00    -- deliberate press, can drop faster
local RELEASE_GRACE_SCOPE     = 0.00    -- toggle, not a hold: no lingering

-- UEVR UI panel
local MANAGE_UI_PANEL   = true
local HIDDEN_DISTANCE   = "0.500000"    -- STRING. too close to focus = hidden
local VISIBLE_DISTANCE  = "2.875000"    -- STRING. thumbrest peek distance
local RB_DISTANCE       = "2.875000"    -- STRING. order wheel distance
local SCOPE_DISTANCE    = "1.875000"    -- STRING. scoped reticle distance
local MENU_DISTANCE     = "2.875000"    -- STRING. main menu / no pawn

-- RB behaviour. false (default) = order wheel only, everything else stays
-- hidden including the ammo counter. true = RB behaves exactly like the
-- thumbrest and brings up the whole HUD.
local RB_SHOWS_ALL_UI   = false

------------------------------------------------------------------
-- UEVR panel geometry, per state
--
-- These are the same three mod values UEVR exposes in its own menu. The
-- default block is what you want essentially everywhere; the per-state table
-- overrides it for individual states only. nil entry = use the default.
--
-- idle is overridden because the panel is showing nothing but the ammo box,
-- and at UI_Size 2.0 that box is too big and sits in the wrong place. Tune
-- the idle numbers until the box lands where you want it; every other state
-- keeps the standard geometry.
--
-- STRINGS, like every other set_mod_value argument.
------------------------------------------------------------------
local MANAGE_UI_GEOMETRY = true

local UI_GEOMETRY_DEFAULT = {
    size = "2.000000",
    x    = "0.000000",
    y    = "0.000000",
}

local UI_GEOMETRY = {
    idle  = { size = "1.200000", x = "0.000000", y = "-0.250000" },
    thumb = nil,        -- nil -> UI_GEOMETRY_DEFAULT
    rb    = nil,
    solo  = nil,
    menu  = nil,
}
local REASSERT_INTERVAL = 0.25          -- re-pin current desired value

-- Weapon scope (right stick click) as a third peek trigger.
-- Entering the scope holds the panel at VISIBLE_DISTANCE for as long as the
-- scope is up; leaving it falls back to whatever the hold triggers say, which
-- is HIDDEN_DISTANCE unless the thumbrest or RB is also engaged.
--
-- Read off pawn.bIsZoomed, NOT the R3 button: the zoom is a toggle, and
-- HolsterScript.lua injects and swallows XINPUT_GAMEPAD_RIGHT_THUMB around
-- lines 274-305, so the button is not a reliable signal. bIsZoomed confirmed
-- in object_dump_1.txt at /Script/SpaceHulkGame.SHTerminator.bIsZoomed.
local MANAGE_SCOPE      = true

-- Scope also swaps aim method to HMD, restoring the controller on exit.
-- This is deliberately keyed to the scope alone and NOT to the thumbrest or
-- RB peek -- touching the thumbrest should never move your aim origin.
-- Set false if you would rather keep aim handling in its own script.
-- UEVR aim method: 0 = game, 1 = head/HMD, 2 = right controller, 3 = left.
local MANAGE_AIM_METHOD = true
local SCOPE_AIM_METHOD  = "1"           -- STRING. HMD
local NORMAL_AIM_METHOD = "2"           -- STRING. right controller

-- Scope "solo UI": collapse the game's viewport HUD widgets while scoped so
-- only BPW_ZoomUI (the reticle) remains on the UEVR panel.
--
-- UEVR composites all viewport-space UI into ONE quad, which is why
-- UI_Distance moves everything together. The widgets inside that quad are
-- separate UUserWidget objects though, and UMG.Widget.SetVisibility
-- (object_dump_1.txt line 7753) applies per widget. So: push the layer to a
-- readable distance, then collapse everything on it except the reticle.
--
-- BPW_ZoomUI_C is spawned by SHPlayerController from CurrentZoomMenuClass and
-- is NOT a child of BPW_PlayerHUD_C -- its child list contains no zoom slot --
-- so collapsing the HUD root leaves the reticle alone. It is simply absent
-- from the hide list below.
--
-- This is separate from the WidgetComponent sweep further down. That one
-- handles Space == 1 components; these are viewport widgets. Different objects,
-- different mechanism.
local SCOPE_SOLO_UI     = true

-- Viewport widgets are now managed in THREE states, not just scoped/not:
--
--   idle    (default on load)  everything in VIEWPORT_HIDE_WIDGETS collapsed
--                              EXCEPT the ammo counter, which stays up
--   peeked  (thumbrest / RB)   everything restored
--   solo    (scoped)           everything collapsed, ammo included, so only
--                              the reticle remains
--
-- Set HIDE_VIEWPORT_WHEN_IDLE = false to go back to v3 behaviour, where the
-- viewport layer was only ever touched by the scope.
local HIDE_VIEWPORT_WHEN_IDLE = true

-- The ammo counter exists twice: as a viewport widget (BPW_HUDWeapon_C) and
-- as a screen-space WidgetComponent on the weapon actor. Both are exempted
-- while idle so the count stays readable with the rest of the HUD gone.
local AMMO_ALWAYS_VISIBLE = true
-- The viewport half of the ammo counter now lives in the "ammo" group below.

-- Teleport / Psy Gate event panel gets its own UI distance while on screen.
-- These widgets are spawned for the event and torn down after, so presence of
-- an instance is the signal. Deliberately absent from VIEWPORT_HIDE_WIDGETS --
-- if we collapsed them the detection below would still fire but you would be
-- staring at a repositioned invisible panel.
local MANAGE_PORTAL_PANEL = true
local PORTAL_DISTANCE     = "1.00000"  -- STRING. closer than normal peek
local PORTAL_WIDGETS = {
    "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_LaunchPsyGate.BPW_LaunchPsyGate_C",
    "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_CountdownPsyGate.BPW_CountdownPsyGate_C",
}

-- Logs which of the classes below actually have live instances, plus whether
-- BPW_ZoomUI_C was found. Fires once now rather than on every state change --
-- v3 logged eleven lines per scope entry. Turn off once settled.
local SCOPE_UI_DISCOVERY = true

-- Paths verified against object_dump_1.txt. Hiding the root (BPW_PlayerHUD_C)
-- covers most of the HUD on its own; the rest are listed because they are
-- spawned independently or may sit outside the root.
-- Per-group hide policy. Each group names one on-screen element (or a set
-- that always travels together) and states what it does in each of the three
-- states. That is the granularity: change one group without touching others.
--
--   idle  no trigger held        peek  thumbrest / RB       solo  scoped
--   "hide" collapse | "show" leave alone
--
-- Use ZZ_UIInventory.lua (press L3) to map an on-screen element you cannot
-- place to a class name -- dump with it visible, dump with it gone, diff.
--
-- Groups with an empty class list are placeholders for elements not yet
-- identified. Fill them from the inventory dump.
local UI_GROUPS = {
    {   name = "ammo", idle = "show", thumb = "show", rb = "hide", solo = "hide",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/BPW_HUDWeapon.BPW_HUDWeapon_C",
        } },

    -- Squad order wheel. RB shows this and nothing else, which is why it has
    -- its own group rather than sitting with the other overlays.
    {   name = "order_wheel", idle = "hide", thumb = "show", rb = "show", solo = "hide",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/BPW_FastOrder2.BPW_FastOrder2_C",
        } },

    {   name = "hud_root", idle = "hide", thumb = "show", rb = "hide", solo = "hide",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/BPW_PlayerHUD.BPW_PlayerHUD_C",
        } },

    -- Armor / health status window and teammate health entries.
    {   name = "life", idle = "hide", thumb = "show", rb = "hide", solo = "hide",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/BPW_HUDLife.BPW_HUDLife_C",
        } },

    -- Minimap / radar and room name labels.
    {   name = "radar", idle = "hide", thumb = "show", rb = "hide", solo = "hide",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/BPW_HUDRadar.BPW_HUDRadar_C",
            "WidgetBlueprintGeneratedClass /Game/Blueprints/HUD/Radar/BPW_RoomName.BPW_RoomName_C",
        } },

    -- Ability glyphs and cooldown markers.
    {   name = "abilities", idle = "hide", thumb = "show", rb = "hide", solo = "hide",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_Psy-Hud-Slot.BPW_Psy-Hud-Slot_C",
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_PsyGate-Hud-Slot.BPW_PsyGate-Hud-Slot_C",
        } },

    {   name = "overlays", idle = "hide", thumb = "show", rb = "hide", solo = "hide",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_ChargeMedkit.BPW_ChargeMedkit_C",
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_HUDPlaceObject.BPW_HUDPlaceObject_C",
        } },

    -- Never touched in any state: mission timers stay up.
    {   name = "timers", idle = "show", thumb = "show", rb = "show", solo = "show",
        classes = {
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_CountdownFail_Generic.BPW_CountdownFail_Generic_C",
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_CountdownPsyGate.BPW_CountdownPsyGate_C",
            "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/HUD/BPW_Autosave.BPW_Autosave_C",
        } },
}

-- Flattened for iteration; built once at load.
local VIEWPORT_HIDE_WIDGETS = {}
for _, g in ipairs(UI_GROUPS) do
    for _, c in ipairs(g.classes) do
        VIEWPORT_HIDE_WIDGETS[#VIEWPORT_HIDE_WIDGETS + 1] = c
    end
end


-- Class of the reticle, checked by the discovery pass only.
local SCOPE_KEEP_WIDGET =
    "WidgetBlueprintGeneratedClass /Game/Blueprints/Experimental/UIexp/ZoomUI/BPW_ZoomUI.BPW_ZoomUI_C"

-- UI Follows View: forced OFF while peeking, restored on release.
-- Key CONFIRMED against the profile config.txt. The probe below is kept
-- only as a sanity check -- if the key ever stops reading back a boolean
-- (build change, renamed option) the feature disables itself and logs
-- that, rather than silently writing into a dead key.
local MANAGE_UI_FOLLOW  = true
local UI_FOLLOW_PEEK    = "false"       -- STRING. value forced while peeking
local UI_FOLLOW_HOLD    = false         -- MainHandler.lua no longer rewrites
                                        -- UI_FollowView every tick, so the
                                        -- per-tick fight is obsolete. Edge
                                        -- writes now survive on their own.
                                        -- Set back to true only if something
                                        -- else starts contending for the key.
local UI_FOLLOW_CANDIDATES = {
    "UI_FollowView",                    -- confirmed
}

-- Game HUD widgets
local MANAGE_HUD        = true
local HUD_HIDE_MODE     = "visibility"  -- "visibility" | "detach"

-- Ammo counter
local MANAGE_AMMO       = true
local AMMO_HIDE_MODE    = "visibility"  -- "visibility" | "detach"

-- Widget sweep
local SCAN_INTERVAL     = 0.5           -- periodic re-sweep (new spawns / re-hide)
local VIS_COLLAPSED     = 1             -- ESlateVisibility::Collapsed

-- Skip any component whose full name OR hosted widget class full name
-- contains one of these fragments. If hiding something breaks input or
-- an interaction prompt, the log names it -- add that fragment here.
local EXCLUDE = {
    -- "Interaction",
    -- "Subtitle",
    -- "Prompt",
}

local DEBUG_LOG         = true
------------------------------------------------------------------

local XINPUT_GAMEPAD_RB = 0x0200

-- Thumbrest wiring (same as GestureDPad.lua)
local thumbrestPath   = "/actions/default/in/ThumbrestTouchRight"
local RightHandle     = vr.get_right_joystick_source()
local thumbrestAction = vr.get_action_handle(thumbrestPath)

local function logmsg(msg)
    if not DEBUG_LOG then return end
    pcall(function()
        if params.functions and params.functions.log_info then
            params.functions.log_info("[UIPeek] " .. msg)
        end
    end)
end

------------------------------------------------------------------
-- UEVR UI panel distance
------------------------------------------------------------------
local function set_distance(str)
    pcall(function() vr.set_mod_value("UI_Distance", str) end)
end

local function read_mod(key)
    local ok, v = pcall(function() return vr:get_mod_value(key) end)
    if ok and v ~= nil then return tostring(v) end
    return nil
end

------------------------------------------------------------------
-- Panel geometry (UI_Size / UI_X_Offset / UI_Y_Offset)
-- Written only when the resolved values actually change, so this does not
-- fight anything else on a per-tick basis.
------------------------------------------------------------------
local lastGeom = nil

local function geometry_for(state)
    local g = UI_GEOMETRY[state]
    if g == nil then return UI_GEOMETRY_DEFAULT end
    return {
        size = g.size or UI_GEOMETRY_DEFAULT.size,
        x    = g.x    or UI_GEOMETRY_DEFAULT.x,
        y    = g.y    or UI_GEOMETRY_DEFAULT.y,
    }
end

local function apply_geometry(state, force)
    if not MANAGE_UI_GEOMETRY then return end
    local g   = geometry_for(state)
    local key = g.size .. "|" .. g.x .. "|" .. g.y
    if not force and key == lastGeom then return end
    lastGeom = key
    pcall(function() vr.set_mod_value("UI_Size",     g.size) end)
    pcall(function() vr.set_mod_value("UI_X_Offset", g.x)    end)
    pcall(function() vr.set_mod_value("UI_Y_Offset", g.y)    end)
    logmsg(string.format("geometry[%s] size=%s x=%s y=%s", state, g.size, g.x, g.y))
end

local function read_distance()
    return read_mod("UI_Distance") or "<read failed>"
end

------------------------------------------------------------------
-- UI Follows View  (key: UI_FollowView, confirmed in config.txt)
-- Whatever value the key holds at load is treated as YOUR default and
-- written back when the peek ends -- nothing is hardcoded. The boolean
-- shape check is a guard against a future build renaming the option:
-- an unknown key can read back empty or echo itself, which would look
-- like a hit and leave us writing into nothing.
------------------------------------------------------------------
local uiFollowKey     = nil
local uiFollowDefault = nil

local function looks_boolean(s)
    return s == "true" or s == "false" or s == "1" or s == "0"
end

if MANAGE_UI_FOLLOW then
    for _, k in ipairs(UI_FOLLOW_CANDIDATES) do
        local v = read_mod(k)
        if v ~= nil and looks_boolean(v) then
            uiFollowKey     = k
            uiFollowDefault = v
            break
        end
    end
end

local function set_follow(str)
    if uiFollowKey == nil or str == nil then return end
    pcall(function() vr.set_mod_value(uiFollowKey, str) end)
end

------------------------------------------------------------------
-- Trigger state
------------------------------------------------------------------
local rb_callback_held = false
local rb_callback_seen = false

callbacks.on_xinput_get_state(function(retval, user_index, state)
    if not state or not state.Gamepad then return end
    rb_callback_seen = true
    rb_callback_held = (state.Gamepad.wButtons & XINPUT_GAMEPAD_RB) ~= 0
end)

local function rb_held()
    if not USE_RB then return false end
    if rb_callback_seen then return rb_callback_held end
    local st = params.sdk.get_xinput_state and params.sdk.get_xinput_state(0) or nil
    if st and st.Gamepad then
        return (st.Gamepad.wButtons & XINPUT_GAMEPAD_RB) ~= 0
    end
    return false
end

local function thumbrest_held()
    if not USE_THUMBREST then return false end
    if RightHandle and thumbrestAction then
        return vr.is_action_active(thumbrestAction, RightHandle) and true or false
    end
    return false
end

------------------------------------------------------------------
-- Scope trigger
------------------------------------------------------------------
local function scope_held()
    if not MANAGE_SCOPE then return false end
    local pawn = uevr.api:get_local_pawn(0)
    if pawn == nil then return false end
    local ok, z = pcall(function() return pawn.bIsZoomed end)
    if not ok or z == nil then return false end
    return z and true or false
end

local function set_aim_method(str)
    if not MANAGE_AIM_METHOD or str == nil then return end
    pcall(function() vr.set_mod_value("VR_AimMethod", str) end)
end

------------------------------------------------------------------
-- Widget registry
--   key = component full name
--   entry = {
--     comp      = WidgetComponent
--     ammo      = bool
--     mode      = "visibility" | "detach"
--     widgetId  = identity string of the hosted widget we cached from
--     origVis   = cached ESlateVisibility byte (visibility mode)
--     detached  = cached widget object   (detach mode)
--     hidden    = bool, whether WE are currently hiding it
--   }
------------------------------------------------------------------
local widgets = {}

local function objId(o)
    local ok, a = pcall(function() return o:get_address() end)
    if ok and a ~= nil then return tostring(a) end
    local ok2, n = pcall(function() return o:get_full_name() end)
    if ok2 and n ~= nil then return n end
    return nil
end

local function excluded(c)
    if #EXCLUDE == 0 then return false end
    local ok, full = pcall(function() return c:get_full_name() end)
    if ok and full then
        for _, frag in ipairs(EXCLUDE) do
            if full:find(frag, 1, true) then return true end
        end
    end
    local ok2, wc = pcall(function() return c.WidgetClass end)
    if ok2 and wc ~= nil then
        local ok3, name = pcall(function() return wc:get_full_name() end)
        if ok3 and name then
            for _, frag in ipairs(EXCLUDE) do
                if name:find(frag, 1, true) then return true end
            end
        end
    end
    return false
end

-- Classification carried over verbatim from AmmoCounterUI.lua
-- WidgetClass only. v3 also matched any component whose owning actor was a
-- Bolter/Cannon/Flamer/Plasma, but a weapon actor hosts SEVERAL screen-space
-- WidgetComponents, so every one of them inherited the ammo exemption and
-- stayed visible while idle. Flip this to restore the loose behaviour if some
-- weapon's counter turns out not to use HUDWeapon.
local AMMO_MATCH_BY_OWNER = false

local function isAmmoWidget(c)
    local ok, wc = pcall(function() return c.WidgetClass end)
    if ok and wc ~= nil then
        local ok2, n = pcall(function() return wc:get_full_name() end)
        if ok2 and n and n:find("HUDWeapon") then return true end
    end
    if not AMMO_MATCH_BY_OWNER then return false end
    local ok3, f = pcall(function() return c:get_full_name() end)
    return ok3 and f ~= nil and (f:find("Bolter") or f:find("Cannon")
        or f:find("Flamer") or f:find("Plasma")) or false
end

local function getWidget(c)
    local w = nil
    pcall(function() w = c.Widget end)
    return w
end

------------------------------------------------------------------
-- Hide / restore
------------------------------------------------------------------
local hideEntry, restoreEntry

hideEntry = function(key, e)
    local c = e.comp
    local w = getWidget(c)

    if e.mode == "detach" then
        if w ~= nil then
            e.detached = w
            e.widgetId = objId(w)
            local ok = pcall(function()
                if c.SetWidget ~= nil then c:SetWidget(nil) end
            end)
            if ok then
                if not e.hidden then logmsg("detach-hid " .. key) end
                e.hidden = true
            end
        end
        return
    end

    -- visibility mode
    if w == nil then return end

    local id = objId(w)
    if id ~= e.widgetId then
        -- component swapped in a different widget: cache is stale
        e.widgetId = id
        e.origVis  = nil
        e.hidden   = false
    end

    if e.origVis == nil then
        local ok, v = pcall(function() return w.Visibility end)
        local cur = (ok and v ~= nil) and v or 0
        -- Same rule as the viewport layer: never adopt a widget the game has
        -- already collapsed, or restore will put it back to invisible forever.
        if cur == VIS_COLLAPSED then return end
        e.origVis = cur
    end

    local okCur, cur = pcall(function() return w.Visibility end)
    if e.hidden and okCur and cur == VIS_COLLAPSED then return end  -- still hidden

    local hasFn = false
    pcall(function() hasFn = (w.SetVisibility ~= nil) end)
    if not hasFn then
        logmsg("SetVisibility missing on " .. key .. " -- falling back to detach mode")
        e.mode = "detach"
        return hideEntry(key, e)
    end

    local ok = pcall(function() w:SetVisibility(VIS_COLLAPSED) end)
    if not ok then
        logmsg("SetVisibility CALL FAILED on " .. key .. " -- falling back to detach mode")
        e.mode = "detach"
        return hideEntry(key, e)
    end

    if not e.hidden then
        logmsg(string.format("hid %s (origVis=%s)", key, tostring(e.origVis)))
    end
    e.hidden = true
end

restoreEntry = function(key, e)
    local c = e.comp

    if e.mode == "detach" then
        if e.detached ~= nil then
            local cur = getWidget(c)
            if cur == nil then
                -- NOTE: if the engine garbage collected the detached widget
                -- this is the call that will crash. Prefer "visibility" mode.
                local ok = pcall(function()
                    if c.SetWidget ~= nil then c:SetWidget(e.detached) end
                end)
                if not ok then logmsg("re-attach FAILED on " .. key) end
            end
        end
        e.hidden = false
        return
    end

    local w = getWidget(c)
    if w == nil then return end
    local id = objId(w)

    if e.hidden and id == e.widgetId then
        pcall(function() w:SetVisibility(e.origVis or 0) end)
        e.hidden = false
        return
    end

    -- Not hidden by us right now (or widget was replaced): refresh the
    -- cache so the NEXT hide restores whatever the game actually wants.
    e.widgetId = id
    e.hidden   = false
    local ok, v = pcall(function() return w.Visibility end)
    if ok and v ~= nil and v ~= VIS_COLLAPSED then e.origVis = v end
end

------------------------------------------------------------------
-- Sweep
------------------------------------------------------------------
-- soloMode is the uiState string ("idle" | "thumb" | "rb" | "solo"), not a
-- bool. Kept the parameter name to avoid churn at the call site.
local function sweepWidgets(wantVisible, soloMode)
    if not (MANAGE_HUD or MANAGE_AMMO) then return end

    local cls = uevr.api:find_uobject("Class /Script/UMG.WidgetComponent")
    if cls == nil then return end
    local ok, comps = pcall(function() return cls:get_objects_matching(false) end)
    if not ok or comps == nil then return end

    local seen = {}

    for _, c in ipairs(comps) do
        pcall(function()
            -- CRITICAL: screen space only. Never touch Space == 0.
            local okS, space = pcall(function() return c.Space end)
            if not okS or space ~= 1 then return end
            if excluded(c) then return end

            local ammo = isAmmoWidget(c)
            if ammo and not MANAGE_AMMO then
                if not MANAGE_HUD then return end
                ammo = false                      -- fold into generic HUD group
            elseif (not ammo) and not MANAGE_HUD then
                return
            end

            local key = c:get_full_name()
            seen[key] = true

            local e = widgets[key]
            if e == nil then
                e = {
                    comp   = c,
                    ammo   = ammo,
                    mode   = ammo and AMMO_HIDE_MODE or HUD_HIDE_MODE,
                    hidden = false,
                }
                widgets[key] = e
                logmsg(string.format("track %s [%s / %s]", key,
                    ammo and "AMMO" or "HUD", e.mode))
            else
                e.comp = c
            end

            -- The ammo counter stays up while idle; only the scope's solo
            -- mode takes it down. Passing soloMode lets the sweep tell the
            -- difference between "not peeking" and "scoped".
            -- Solo (scoped) hides EVERYTHING, ammo included. v3 passed
            -- wantVisible=true while scoped -- scope folds into `engaged` --
            -- so this branch restored every component underneath the viewport
            -- hiding, which is why HUD elements stayed on screen while scoped.
            local show
            if soloMode == "menu" then
                show = true                       -- never touch menu UI
            elseif soloMode == "solo" then
                show = false                      -- scoped: reticle only
            elseif soloMode == "thumb" then
                show = true                       -- thumbrest: everything
            elseif soloMode == "rb" then
                show = false                      -- order wheel only, ammo included
            else
                -- idle: ammo counter only
                show = (ammo and AMMO_ALWAYS_VISIBLE) or false
            end

            if show then
                restoreEntry(key, e)
            else
                hideEntry(key, e)
            end
        end)
    end

    for k, _ in pairs(widgets) do
        if not seen[k] then widgets[k] = nil end
    end
end

------------------------------------------------------------------
-- Scope solo UI: collapse viewport HUD widgets, leave the reticle
--
-- Non-destructive by design: the widget's own Visibility byte is cached and
-- written back. Nothing is detached, nothing is removed from the viewport, so
-- there is no dangling pointer and no re-init cycle -- same reasoning as
-- "visibility" mode in the WidgetComponent sweep above.
------------------------------------------------------------------
local viewportHidden = {}       -- widget full name -> { w, origVis, path }
local discoveryDone  = false

-- Class lookups are cached. v3 resolved them on every call, and the log showed
-- the first scope entry costing ~1.02s of blocked game thread (60-100ms per
-- find_uobject across eleven classes), which starved the tick callback mid
-- FOV interpolation. Subsequent entries were sub-millisecond, so the cost was
-- entirely first-resolve. `false` is cached for misses so they are not retried.
local widgetClassCache = {}

local function widgetsOfClass(path)
    local cls = widgetClassCache[path]
    if cls == nil then
        cls = uevr.api:find_uobject(path) or false
        widgetClassCache[path] = cls
    end
    if not cls then return nil end
    local ok, objs = pcall(function() return cls:get_objects_matching(false) end)
    if not ok or objs == nil then return nil end
    return objs
end

local function countOfClass(path)
    local objs = widgetsOfClass(path)
    if objs == nil then return 0 end
    local n = 0
    for _ in ipairs(objs) do n = n + 1 end
    return n
end

-- Retries until it actually finds instances. Running once meant it fired
-- during load, before any HUD widget existed, and reported 0 live for every
-- class -- which told us nothing.
local function runDiscovery()
    if not SCOPE_UI_DISCOVERY or discoveryDone then return end

    local counts, total = {}, 0
    for _, path in ipairs(VIEWPORT_HIDE_WIDGETS) do
        local c = countOfClass(path)
        counts[path] = c
        total = total + c
    end
    if total == 0 then return end        -- HUD not up yet, try again next sweep

    discoveryDone = true
    logmsg(string.format("discovery: BPW_ZoomUI_C instances = %d",
        countOfClass(SCOPE_KEEP_WIDGET)))
    for _, path in ipairs(VIEWPORT_HIDE_WIDGETS) do
        local short = path:match("([^%.]+)$") or path
        logmsg(string.format("discovery: %s -> %d live", short, counts[path]))
    end
end

local function hideViewportWidget(path)
    local objs = widgetsOfClass(path)
    if objs == nil then return end
    for _, w in ipairs(objs) do
        local okName, key = pcall(function() return w:get_full_name() end)
        if okName and key ~= nil and viewportHidden[key] == nil then
            local okVis, v = pcall(function() return w.Visibility end)
            local orig = (okVis and v ~= nil) and v or 0

            -- If the GAME already has it collapsed, it is not ours to manage.
            -- Caching Collapsed as the "original" is what made the ammo counter
            -- vanish permanently: restore wrote Collapsed back, the next idle
            -- pass re-cached from that, and it never recovered. Skipping means
            -- the 0.5s sweep picks it up later once the game makes it visible,
            -- and caches the real value then.
            if orig == VIS_COLLAPSED then goto continue end

            -- Cache the REAL value, collapsed included. v3 forced collapsed to
            -- Visible here, which turned every game-collapsed element (ability
            -- glyphs on cooldown, empty psy slots, inactive indicators) ON at
            -- restore. We only read this before hiding, so it is always the
            -- game's own value and never our own collapse.

            if pcall(function() w:SetVisibility(VIS_COLLAPSED) end) then
                viewportHidden[key] = { w = w, origVis = orig, path = path }
            else
                logmsg("SetVisibility failed on " .. tostring(key))
            end
        end
        ::continue::
    end
end

-- mode: "show" (restore all) | "idle" (hide all but ammo) | "solo" (hide all)
--
-- Reconciles rather than assuming a starting point: anything currently hidden
-- whose class should now be visible gets restored first, then anything that
-- should be hidden and is not yet gets collapsed. That makes it safe to call
-- every sweep, which is what picks up widgets spawned after the state change
-- (BPW_RoomName_C instances come and go as you move through the level).
local function applyViewport(mode)
    if not SCOPE_SOLO_UI and not HIDE_VIEWPORT_WHEN_IDLE then return end

    local wantHidden = {}
    for _, g in ipairs(UI_GROUPS) do
        local policy = g[mode] or "show"
        if policy == "hide" then
            -- Master switches still win over group policy. The ammo special
            -- case is gone: the group table states ammo's policy per state
            -- directly, which is the whole point of having the table.
            local allowed = true
            if mode == "idle" and not HIDE_VIEWPORT_WHEN_IDLE then allowed = false end
            if mode == "solo" and not SCOPE_SOLO_UI then allowed = false end
            if allowed then
                for _, c in ipairs(g.classes) do wantHidden[c] = true end
            end
        end
    end

    for key, e in pairs(viewportHidden) do
        if not wantHidden[e.path] then
            pcall(function() e.w:SetVisibility(e.origVis) end)
            viewportHidden[key] = nil
        end
    end

    for _, path in ipairs(VIEWPORT_HIDE_WIDGETS) do
        if wantHidden[path] then hideViewportWidget(path) end
    end
end

local function viewportRestoreAll()
    applyViewport("show")
end

------------------------------------------------------------------
-- Teleport / Psy Gate panel detection
--
-- The event widgets are spawned on demand and destroyed afterwards, so a live
-- instance IS the event. No state flag to read and no edge to miss.
------------------------------------------------------------------
local function portal_active()
    if not MANAGE_PORTAL_PANEL then return false end
    for _, path in ipairs(PORTAL_WIDGETS) do
        if countOfClass(path) > 0 then return true end
    end
    return false
end

------------------------------------------------------------------
-- State + tick
------------------------------------------------------------------
local current_time   = 0.0
local appliedVisible = nil     -- nil forces first apply (hidden by default)
local scopeApplied   = false   -- last scope state we acted on
local portalApplied  = false   -- last portal-panel state we acted on
local graceState     = nil     -- state held through the release grace
local appliedState   = nil     -- last uiState we logged
local hideAtTime     = 0.0
local reassertAccum  = 0.0
local scanAccum      = 0.0
local forceScan      = true

if MANAGE_UI_FOLLOW then
    if uiFollowKey then
        logmsg(string.format("follow-view key resolved: %s = %s (treated as default)",
            uiFollowKey, tostring(uiFollowDefault)))
    else
        logmsg("follow-view key NOT resolved -- none of the candidates read back "
            .. "a boolean. Check config.txt for the real key name. Feature inactive.")
    end
end

logmsg("v3 loaded; startup UI_Distance = " .. read_distance()
    .. string.format(" | panel=%s hud=%s(%s) ammo=%s(%s)",
        tostring(MANAGE_UI_PANEL), tostring(MANAGE_HUD), HUD_HIDE_MODE,
        tostring(MANAGE_AMMO), AMMO_HIDE_MODE))

callbacks.on_pre_engine_tick(function(engine, delta)
    local dt = delta or 0
    current_time = current_time + dt

    ----------------------------------------------------------------
    -- Scope edge: drives aim method only. The panel distance is handled
    -- by folding scope into `engaged` just below, so it inherits the
    -- existing grace period and re-assert logic for free.
    ----------------------------------------------------------------
    local scoped = scope_held()
    if scoped ~= scopeApplied then
        scopeApplied = scoped
        set_aim_method(scoped and SCOPE_AIM_METHOD or NORMAL_AIM_METHOD)
        forceScan = true
        logmsg(string.format("scope %s -> VR_AimMethod=%s",
            scoped and "ON" or "OFF", read_mod("VR_AimMethod") or "<read failed>"))
    end

    local inMenu = (uevr.api:get_local_pawn(0) == nil)

    local thumb = thumbrest_held()
    local rb    = rb_held()

    -- Per-trigger grace: whichever active trigger has the longest linger wins,
    -- so releasing one while another is still held never truncates the peek.
    local engaged = thumb or rb or scoped
    if engaged then
        local grace = 0.0
        if thumb  and RELEASE_GRACE_THUMBREST > grace then grace = RELEASE_GRACE_THUMBREST end
        if rb     and RELEASE_GRACE_RB        > grace then grace = RELEASE_GRACE_RB        end
        if scoped and RELEASE_GRACE_SCOPE     > grace then grace = RELEASE_GRACE_SCOPE     end
        hideAtTime = current_time + grace
    end

    local wantVisible = engaged or (current_time < hideAtTime)

    -- FOUR states now, because RB and thumbrest want different things:
    -- RB brings up the order wheel alone, thumbrest brings up everything.
    -- Scope outranks both. During the release grace the previous state is
    -- held rather than snapping to idle, or the grace would do nothing.
    local uiState
    if inMenu then
        -- No pawn means main menu (or a level transition). The menu is its own
        -- UI and must never inherit the idle hide-everything treatment -- that
        -- is what stranded it at 0.5 after returning from a level.
        uiState = "menu"
    elseif scoped then
        uiState = "solo"
    elseif thumb then
        uiState = "thumb"
    elseif rb then
        uiState = "rb"
    elseif wantVisible and graceState ~= nil then
        uiState = graceState
    else
        uiState = "idle"
    end
    if scoped or thumb or rb then graceState = uiState end

    -- RB_SHOWS_ALL_UI makes RB use the thumbrest hide policy while keeping its
    -- own distance and geometry.
    local policyState = uiState
    if uiState == "rb" and RB_SHOWS_ALL_UI then policyState = "thumb" end

    local viewportMode = policyState

    ----------------------------------------------------------------
    -- UEVR UI panel
    ----------------------------------------------------------------
    -- Distance priority: portal event > peek/scope > hidden. The portal panel
    -- is the whole point of the event, so it outranks a thumbrest peek.
    -- Swap the first two branches to let peeking override it.
    local portalNow = portal_active()
    local desiredDistance
    if portalNow then
        desiredDistance = PORTAL_DISTANCE
    elseif uiState == "menu" then
        desiredDistance = MENU_DISTANCE
    elseif uiState == "solo" then
        desiredDistance = SCOPE_DISTANCE
    elseif uiState == "rb" then
        desiredDistance = RB_DISTANCE
    elseif uiState == "thumb" then
        desiredDistance = VISIBLE_DISTANCE
    else
        desiredDistance = HIDDEN_DISTANCE
    end

    if portalNow ~= portalApplied then
        portalApplied = portalNow
        logmsg(string.format("portal panel %s -> UI_Distance %s",
            portalNow and "OPEN" or "CLOSED", desiredDistance))
        if MANAGE_UI_PANEL then set_distance(desiredDistance) end
        reassertAccum = 0.0
    end

    if wantVisible ~= appliedVisible or uiState ~= appliedState then
        appliedVisible = wantVisible
        appliedState   = uiState
        apply_geometry(uiState, false)
        if MANAGE_UI_PANEL then
            set_distance(desiredDistance)
        end
        -- Follow-view is FOUGHT FOR, not set once. MainHandler.lua's
        -- MenuStatus() rewrites UI_FollowView every tick from both
        -- branches, so a transition-only write survives exactly one
        -- frame. See the per-tick hold below.
        -- On release we write the captured default once and then stop
        -- touching it -- MainHandler owns it again, and it drives the
        -- value off real menu state, which is more correct than
        -- anything we'd re-assert.
        if uiFollowKey then
            set_follow(wantVisible and UI_FOLLOW_PEEK or uiFollowDefault)
        end
        reassertAccum = 0.0
        forceScan     = true          -- react to the transition immediately
        logmsg(string.format("state=%-5s policy=%-5s (thumb=%s rb=%s scope=%s menu=%s) -> %s readback %s",
            uiState, policyState, tostring(thumb), tostring(rb),
            tostring(scoped), tostring(inMenu), desiredDistance, read_distance()))
    elseif MANAGE_UI_PANEL and REASSERT_INTERVAL > 0 then
        -- re-pin whichever state we currently want, so nothing else
        -- rewriting UI_Distance can collapse the peek mid-hold
        reassertAccum = reassertAccum + dt
        if reassertAccum >= REASSERT_INTERVAL then
            reassertAccum = 0.0
            -- Must re-pin the RESOLVED distance. This previously wrote the old
            -- two-state value, which stomped the scope / RB / menu distance
            -- every 0.25s and made those settings look like they did nothing.
            set_distance(desiredDistance)
            apply_geometry(uiState, true)
        end
    end

    ----------------------------------------------------------------
    -- Follow-view hold
    -- MainHandler.lua writes UI_FollowView every tick, so we have to
    -- write it every tick too, and we have to write it LAST. That holds
    -- as long as UIPeek.lua loads after MainHandler.lua (alphabetical,
    -- M < U, so callbacks run in that order). If you ever rename either
    -- file, rename this one to ZZ_UIPeek.lua to guarantee it stays last.
    --
    -- Repeated identical writes are safe: MainHandler has been writing
    -- "true" every tick all along with no panel jitter, which is the
    -- evidence that UEVR's setter only re-anchors on an actual change.
    ----------------------------------------------------------------
    if uiFollowKey and UI_FOLLOW_HOLD and appliedVisible then
        set_follow(UI_FOLLOW_PEEK)
    end

    ----------------------------------------------------------------
    -- Game widgets
    ----------------------------------------------------------------
    scanAccum = scanAccum + dt
    if forceScan or scanAccum >= SCAN_INTERVAL then
        scanAccum = 0.0
        forceScan = false
        sweepWidgets(appliedVisible and true or false, policyState)
        runDiscovery()
        applyViewport(viewportMode)
    end
end)
------------------------------------------------------------------
-- Reloading scripts while scoped would otherwise strand aim on HMD.
------------------------------------------------------------------
callbacks.on_script_reset(function()
    if scopeApplied then
        set_aim_method(NORMAL_AIM_METHOD)
        scopeApplied = false
    end
    -- Leave nothing collapsed behind on reload -- idle-hidden widgets included,
    -- or a reset while unpeeked would strand the HUD invisible.
    viewportRestoreAll()
end)