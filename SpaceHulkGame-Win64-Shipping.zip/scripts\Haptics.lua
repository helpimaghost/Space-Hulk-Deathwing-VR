--=====================================================================
-- WeaponHaptics.lua   (recoil/melee/abilities/landing + walking/sprint/reload)
--=====================================================================
-- New-event signals are all dump-verified or read straight from the VR
-- controller -- no reliance on HolsterScript/MainHandler globals, no UFunction
-- hooks (polling only, so it can't crash the injector).
--
-- Dump-verified resources:
--   SHCharac.GetIsReloadingweapon() : bool      (reload)
--   SHTerminator.GetIsInReload()    : bool      (reload, 2nd signal)
--   SHTerminator.ISprint            : bool      (sprint / charge)
--   SHTerminator.fCurrentPsyEnergy  : float     (abilities)
--   SHTerminator.fInitialPsyEnergy  : float     (ability scaling)
--   SHTerminator.PsyPower           : byte       (which power; logged)
--   Character.CharacterMovement -> CharacterMovementComponent.MovementMode : byte (landing/grounded)
--   (Pawn is SHTerminator : SHCharac -> all reachable on the local pawn.)
-- Walking uses the physical left thumbstick via vr.get_joystick_axis, because
-- the mod zeroes the xinput stick during normal (non-sprint) walking.
--=====================================================================

local vr        = uevr.params.vr
local callbacks = uevr.params.sdk.callbacks
local api       = uevr.api
local fns       = uevr.params.functions

--=====================================================================
-- Master tunables
--=====================================================================
-- Amplitude is a NORMALISED 0.0-1.0 value: the VR runtime clamps anything
-- above 1.0. Verified on this hardware with HapticLadder.lua (steps at 1.00,
-- 2.00, 4.00, 8.00 all felt identical). So HAPTIC_STRENGTH must stay <= 1.0 --
-- raising it past 1.0 does not add force, it just pins every event to maximum
-- and destroys all intensity variation.
-- NOTE: frequency is also ignored by this runtime (the 20Hz-1000Hz ladder felt
-- uniform), so DURATION is what differentiates events, not freq.
local HAPTIC_STRENGTH = 1.0
local AMP_CEILING     = 1.0

local RECOIL_ENABLED  = true   -- rumble-based recoil (needs in-game rumble ON)
-- Script-based gunfire, independent of in-game controller rumble.
-- Polls SHDistanceWeapon.currentAmmo on the pawn's weapon actor: a drop = a shot.
-- Dump-verified: SHTerminator.RightWeaponActor / LeftWeaponActor (ObjectProperty)
--                SHDistanceWeapon.currentAmmo (IntProperty)
--                SHDistanceWeapon.AmmoPerMagazine (IntProperty)
local GUNFIRE_ENABLED   = true
local GUNFIRE_COOLDOWN  = 0.03   -- min seconds between shot pulses (fire-rate cap)
local GUNFIRE_LEFT_HAND = false  -- also pulse the LeftWeaponActor's own hand
local MELEE_ENABLED   = true
local MELEE_BOTH_HANDS = true
local ABILITY_ENABLED = true
local RELOAD_ENABLED  = true
local LAND_ENABLED    = true
local DAMAGE_ENABLED  = true
local WALK_ENABLED    = true

local RECOIL_STRENGTH = 1.0     -- gun-only trim (keep total <= 1.0)

-- Debug: writes to UEVR log.txt.
local DEBUG_LOG        = false
local DEBUG_FIRES      = false
local DEBUG_DAMAGE     = false
local DEBUG_HEARTBEAT  = false
local DEBUG_BUTTONS    = false
local HEARTBEAT_PERIOD = 2.0

-- bHaptics event emit. The external bridge (bhaptics_bridge.py) tails this
-- file and plays vest/sleeve patterns. Costs nothing while EMIT_EVENTS=false.
-- EMIT_PATH MUST be absolute: a relative path lands in the game's working
-- directory, which is unpredictable. Edit <YOU> to your Windows username, and
-- use double backslashes.
local EMIT_EVENTS = false
local EMIT_PATH   = "C:\\Users\\<YOU>\\AppData\\Roaming\\UnrealVRMod\\SpaceHulkGame-Win64-Shipping\\haptic_events.jsonl"
-- Truncate the file at load so it can't grow without bound across sessions.
local EMIT_TRUNCATE_ON_LOAD = true

-- Reload button: after the mod's remap, reload is expected on game-X (0x4000).
-- If the button log shows a different bit, set it here.
local RELOAD_BUTTON_MASK = 0x4000

-- Cooldown abilities (no psy-energy cost). Standard XInput masks:
--   A=0x1000  B=0x2000  X=0x4000  Y=0x8000
local ABILITY_B_MASK     = 0x2000   -- B
local ABILITY_Y_MASK     = 0x8000   -- Y
local ABILITY_A_MASK     = 0x1000   -- A (unused; third ability is a B+Y chord)

-- Which power SLOT each button fires. Confirmed from PowerDiag on the
-- Librarian: slot 0 = Shockwave (Y), slot 1 = ChainLightning (B).
local ABILITY_SLOT_FOR_Y = 0
local ABILITY_SLOT_FOR_B = 1
local ABILITY_SLOT_FOR_A = 2
-- The THIRD ability is B + Y pressed together. Because a "simultaneous" press
-- is never actually simultaneous, a single-button press is held for
-- ABILITY_CHORD_WINDOW to see whether the other button joins it. If it does,
-- the chord fires slot 2 and neither single ability fires. If it doesn't, the
-- single ability fires after the window. The cost is that Shockwave and Chain
-- Lightning now buzz ~0.09s after the press instead of instantly.
local ABILITY_THIRD_CHORD  = true
local ABILITY_CHORD_WINDOW = 0.09

-- How often to re-read which abilities occupy which slots (class/loadout change).
local ABILITY_SLOT_REFRESH = 5.0

-- Ability trigger inputs.
-- NOTE: the right-thumbstick ability mapping in ControlInput.lua is leftover
-- from a different game and is being removed, so stick triggering is OFF.
-- Abilities are on face buttons; the exact codes that survive ControlInput's
-- remapping are being confirmed via the button log (DEBUG_BUTTONS below).
local ABILITY_USE_RIGHT_STICK = false
local ABILITY_STICK_THRESHOLD = 30000

-- Apothecary cooldowns triple without the Narthecium. Set true if playing
-- Apothecary unequipped so its cooldown gating stays correct.
local APOTHECARY_NO_NARTHECIUM = false

--=====================================================================
-- Ability registry: all 18 abilities, matched by their power component
-- class name (e.g. "BP_ChainLightningComponent_C" -> key "chainlightning").
-- cd    = real in-game cooldown in seconds (gates phantom buzzes on presses
--         made while the ability is still recharging)
-- style = which haptic shape to play
--=====================================================================
local ABILITY_STYLE_DEFAULT = "burst"

local ABILITIES = {
	-- Librarian
	{ key = "shockwave",            cd = 10,  style = "shockwave" },
	{ key = "chainlightning",       cd = 8,   style = "lightning" },
	{ key = "spontaneouscombustion",cd = 64,  style = "burn"      },
	-- Apothecary (cd tripled without Narthecium)
	{ key = "massheal",             cd = 72,  style = "heal", apo = true },
	{ key = "autoheal",             cd = 55,  style = "heal", apo = true },
	{ key = "heal",                 cd = 60,  style = "heal", apo = true },
	-- Assault
	{ key = "frenzy",               cd = 80,  style = "buff"   },
	{ key = "deepstrike",           cd = 110, style = "teleport" },
	{ key = "energyfield",          cd = 40,  style = "shield" },
	-- Interrogator-Chaplain
	{ key = "calltoarms",           cd = 110, style = "buff"   },
	{ key = "litanyofwar",          cd = 90,  style = "shield" },
	{ key = "retribution",          cd = 60,  style = "shield" },
	-- Heavy Weapon Specialty
	{ key = "firestorm",            cd = 120, style = "buff"   },
	{ key = "proximitymine",        cd = 50,  style = "deploy" },
	{ key = "crusaders",            cd = 90,  style = "buff"   },
	-- Tactical
	{ key = "reinforcement",        cd = 120, style = "heal"   },
	{ key = "protector",            cd = 50,  style = "shield" },
	{ key = "skullbolter",          cd = 300, style = "deploy" },
}

-- Crackle profiles (rhythm carries texture; frequency is ignored by the runtime)
local BEAM_CRACKLE = {   -- chain lightning: sharp irregular arcing
	duration = 0.90, pulseDur = 0.022, minGap = 0.018, maxGap = 0.075,
	minAmp = 0.55, maxAmp = 1.00, decay = true, decayAmount = 0.45,
}
local BURN_CRACKLE = {   -- spontaneous combustion: slower, rolling
	duration = 1.10, pulseDur = 0.035, minGap = 0.040, maxGap = 0.110,
	minAmp = 0.40, maxAmp = 0.90, decay = true, decayAmount = 0.60,
}
local BEAM_BOTH_HANDS = false   -- true = bolt felt in both hands

-- Two-stage reload: buzz on mag eject, pause, then buzz on new mag seating.
local RELOAD_TWO_STAGE    = true
local RELOAD_INSERT_DELAY = 1.45   -- fallback only: used if ReloadTime is unreadable
-- Prefer engine signals (GetIsInReload + ammo refill) over the X button edge.
local RELOAD_USE_ENGINE_EVENTS = true
-- If the ammo refill isn't observed, land the insert at this fraction of the
-- weapon's real ReloadTime (the mag normally seats near the end of the anim).
-- Fallback fires at ReloadTime * this. Must be > 1.0 so the REAL ammo-refill
-- signal wins the race; the timer is only a safety net if the ammo read fails.
-- (At 0.80 the timer always fired first, so the refill was never used.)
local RELOAD_INSERT_TIME_SCALE = 1.25
-- The engine reload flag blips on a press that can't actually reload, so require
-- it to persist this long before buzzing. Raise if phantom buzzes persist.
local RELOAD_CONFIRM_TIME = 0.12

--=====================================================================
-- Presets {duration, frequency, baseAmp}
--=====================================================================
local P = {
	-- amp values are FINAL 0-1 amplitudes (HAPTIC_STRENGTH is 1.0).
	-- Frequency is ignored by this runtime; duration shapes the feel.
	recoil        = { dur = 0.13, freq = 150.0, amp = 0.95 },  -- sharp kick
	swing         = { dur = 0.20, freq = 260.0, amp = 0.45 },  -- floor; scales to 0.95 with speed
	reload        = { dur = 0.12, freq = 200.0, amp = 0.60 },  -- single-buzz fallback
	reload_eject  = { dur = 0.30, freq = 210.0, amp = 0.45 },  -- lighter: mag drops out
	reload_insert = { dur = 0.40, freq = 150.0, amp = 0.60 },  -- heavier: mag seats
	beam          = { dur = 0.06, freq = 90.0,  amp = 0.40 },  -- light crackle, repeats
	pulse         = { dur = 0.45, freq = 70.0,  amp = 1.00 },  -- biggest single event (amp is at the 1.0 ceiling; weight comes from duration)
	land          = { dur = 0.16, freq = 60.0,  amp = 0.80 },  -- floor; scales to 1.00 with air time
	damage        = { dur = 0.16, freq = 90.0,  amp = 0.35 },  -- floor; scales to 1.00 with hit size
	death         = { dur = 0.60, freq = 45.0,  amp = 1.00 },  -- long heavy "you are down"
	footstep      = { dur = 0.05, freq = 120.0, amp = 0.20 },
}

-- Abilities: classify a psy-energy spend by size (fraction of max energy).
local ABILITY_MIN_DROP_FRAC = 0.010
local ABILITY_BIG_DROP_FRAC = 0.120
local ABILITY_COOLDOWN      = 0.05

-- Landing
local MOVE_WALKING, MOVE_NAVWALK, MOVE_FALLING = 1, 2, 3
local LAND_MIN_AIR, LAND_MAX_AIR = 0.25, 1.5

-- Walking cadence
local WALK_DEADZONE          = 0.20   -- physical stick magnitude (0..1)

-- Per-direction walking patterns. interval = seconds between steps,
-- amp = step intensity (0..1), startFoot = which controller a bout of that
-- direction begins on ("right"/"left"), startDelay = seconds after you start
-- pushing the stick before the first step of that direction fires.
local WALK_DIRS = {
	forward = { interval = 0.524, amp = 0.42, startFoot = "left", startDelay = 0.52 },
	back    = { interval = 0.425, amp = 0.50, startFoot = "right",  startDelay = 0.32 },
	left    = { interval = 0.38, amp = 0.42, startFoot = "left",  startDelay = 0.32 },
	right   = { interval = 0.38, amp = 0.42, startFoot = "right", startDelay = 0.32 },
}
-- Sprint uses one pattern regardless of direction.
local SPRINT_PATTERN = { interval = 0.365, amp = 1.00, startFoot = "right", startDelay = 0.0 }

-- Flip these if a direction feels swapped (depends on stick axis orientation).
local WALK_INVERT_X = false
local WALK_INVERT_Y = false

--=====================================================================
-- Helpers
--=====================================================================
local function clamp(v, lo, hi)
	if v < lo then return lo end
	if v > hi then return hi end
	return v
end
local function rightSrc() return vr.get_right_joystick_source() end
local function leftSrc()  return vr.get_left_joystick_source()  end
local function weaponSrc()
	local weaponIsRight = true
	if isRhand ~= nil then weaponIsRight = isRhand end
	return weaponIsRight and rightSrc() or leftSrc()
end
local function logmsg(s)
	if DEBUG_LOG then pcall(function() fns.log_info("[WeaponHaptics] " .. s) end) end
end

-- reflected reads
local function callBool(obj, method)   -- no-arg bool getter (function)
	if obj == nil then return nil end
	local ok, v = pcall(function() return obj[method](obj) end)
	if ok and type(v) == "boolean" then return v end
	return nil
end
local function readNum(obj, prop)      -- numeric property
	if obj == nil then return nil end
	local ok, v = pcall(function() return obj[prop] end)
	if ok and type(v) == "number" then return v end
	return nil
end
local function readBoolProp(obj, prop) -- bool property
	if obj == nil then return nil end
	local ok, v = pcall(function() return obj[prop] end)
	if ok and type(v) == "boolean" then return v end
	return nil
end
local function readMovementMode(pawn)
	if pawn == nil then return nil end
	local ok, v = pcall(function() return pawn.CharacterMovement.MovementMode end)
	if ok and type(v) == "number" then return v end
	return nil
end

-- physical left thumbstick (x,y in -1..1, plus magnitude), unaffected by the mod's zeroing
local stickVec = UEVR_Vector2f.new()
local function leftStickXY()
	local ok = pcall(function() vr.get_joystick_axis(leftSrc(), stickVec) end)
	if not ok then return 0, 0, 0 end
	local x = stickVec.x or 0
	local y = stickVec.y or 0
	return x, y, math.sqrt(x * x + y * y)
end
local function leftStickMag()
	local _, _, m = leftStickXY()
	return m
end

-- classify stick direction into forward / back / left / right (dominant axis wins)
local function classifyDir(x, y)
	if WALK_INVERT_X then x = -x end
	if WALK_INVERT_Y then y = -y end
	if math.abs(x) > math.abs(y) then
		return (x > 0) and "right" or "left"
	else
		return (y >= 0) and "forward" or "back"
	end
end

--=====================================================================
-- Event emit (bHaptics bridge)
--=====================================================================
local emitQueue = {}
local function queueEvent(name, intensity, loc)
	if not EMIT_EVENTS then return end
	emitQueue[#emitQueue + 1] = string.format(
		'{"t":%.3f,"event":"%s","intensity":%.3f,"loc":"%s"}',
		os.clock(), name, clamp(intensity or 1.0, 0, 1), loc or "hand")
end
local function flushEvents()
	if not EMIT_EVENTS or #emitQueue == 0 then return end
	pcall(function()
		local f = io.open(EMIT_PATH, "a")
		if f then for i = 1, #emitQueue do f:write(emitQueue[i], "\n") end f:close() end
	end)
	emitQueue = {}
end

--=====================================================================
-- Central dispatch (each hand fired independently so one can't block the other)
--=====================================================================
local function fire(source, dur, freq, baseAmp)
	pcall(function()
		vr.trigger_haptic_vibration(0.0, dur, freq, clamp(baseAmp * HAPTIC_STRENGTH, 0.0, AMP_CEILING), source)
	end)
end
local function dispatch(name, source, baseAmp, preset, loc)
	preset  = preset  or P[name]
	baseAmp = baseAmp or preset.amp
	if DEBUG_FIRES then
		local hand = (source == "both") and "BOTH"
			or (source == rightSrc()) and "RIGHT"
			or (source == leftSrc()) and "LEFT" or "?"
		logmsg(string.format("FIRE %-14s hand=%-5s amp=%.2f", name, hand, baseAmp))
	end
	if source == "both" then
		fire(rightSrc(), preset.dur, preset.freq, baseAmp)
		fire(leftSrc(),  preset.dur, preset.freq, baseAmp)
	else
		fire(source, preset.dur, preset.freq, baseAmp)
	end
	queueEvent(name, clamp(baseAmp, 0, 1), loc)
end

--=====================================================================
-- Pulse-train scheduler (texture via rhythm)
--=====================================================================
-- Frequency is ignored by this runtime, so "texture" must come from RHYTHM:
-- a burst of short, irregular, varying-amplitude ticks reads as crackle, while
-- one smooth pulse just reads as a bump.
local pulseQueue = {}

local function schedulePulse(delay, source, amp, dur)
	pulseQueue[#pulseQueue + 1] = { t = delay, src = source, amp = amp, dur = dur }
end

local function tickPulseQueue(delta)
	if #pulseQueue == 0 then return end
	local keep = {}
	for i = 1, #pulseQueue do
		local p = pulseQueue[i]
		p.t = p.t - delta
		if p.t <= 0 then
			if p.src == "both" then
				fire(rightSrc(), p.dur, 0.0, p.amp)
				fire(leftSrc(),  p.dur, 0.0, p.amp)
			else
				fire(p.src, p.dur, 0.0, p.amp)
			end
		else
			keep[#keep + 1] = p
		end
	end
	pulseQueue = keep
end

-- Electric-crackle burst: rapid irregular ticks with amplitude jitter and an
-- optional taper. Emits ONE bHaptics event for the whole burst, not per tick.
local function scheduleCrackle(source, cfg, eventName, loc)
	local t, n, peak = 0.0, 0, 0.0
	while t < cfg.duration do
		local a = cfg.minAmp + math.random() * (cfg.maxAmp - cfg.minAmp)
		if cfg.decay then
			a = a * (1.0 - (t / cfg.duration) * cfg.decayAmount)
		end
		a = clamp(a, 0.0, 1.0)
		if a > peak then peak = a end
		schedulePulse(t, source, a, cfg.pulseDur)
		n = n + 1
		t = t + cfg.minGap + math.random() * (cfg.maxGap - cfg.minGap)
	end
	if eventName then queueEvent(eventName, peak, loc) end
	return n
end

--=====================================================================
-- Ability slot resolution + per-style playback
--=====================================================================
-- slotAbility[i] = { key, cd, style, label } for power slot i (0-based)
local slotAbility = {}
local slotCooldown = {}      -- per-slot remaining cooldown
local slotRefresh = 0.0

-- Match a component's class name ("BP_ChainLightningComponent_C") to the registry.
local function identifyAbility(obj)
	if obj == nil then return nil end
	local name
	local ok = pcall(function() name = obj:get_full_name() end)
	if not ok or name == nil then return nil end
	local lower = string.lower(name)
	-- longest keys first so "massheal"/"autoheal" beat plain "heal"
	for _, a in ipairs(ABILITIES) do
		if string.find(lower, a.key, 1, true) then
			local cd = a.cd
			if a.apo and APOTHECARY_NO_NARTHECIUM then cd = cd * 3 end
			return { key = a.key, cd = cd, style = a.style, label = name }
		end
	end
	return { key = "unknown", cd = 10, style = ABILITY_STYLE_DEFAULT, label = name }
end

function refreshAbilitySlots(pawn)
	if pawn == nil then return end
	for i = 0, 5 do
		local comp
		local ok = pcall(function() comp = pawn:GetPsyPowerComponentForSlot(i) end)
		if ok and comp ~= nil then
			local info = identifyAbility(comp)
			local prev = slotAbility[i]
			if info and (prev == nil or prev.key ~= info.key) then
				logmsg(string.format("slot %d = %s (cd %ds, style %s)",
					i, info.key, info.cd, info.style))
			end
			slotAbility[i] = info
		else
			slotAbility[i] = nil
		end
	end
end

-- Play the haptic shape for an ability style.
local function playAbilityStyle(style)
	if style == "lightning" then
		local src = BEAM_BOTH_HANDS and "both" or weaponSrc()
		scheduleCrackle(src, BEAM_CRACKLE, "beam", "right_hand")
	elseif style == "burn" then
		scheduleCrackle("both", BURN_CRACKLE, "beam", "chest")
	elseif style == "shockwave" then
		-- Amplitude is capped at 1.0, so a shockwave is made to feel BIG through
		-- duration and sustain, not peak strength: a long hard thump, then
		-- overlapping heavy pulses that hold near full power before decaying.
		dispatch("pulse", "both", P.pulse.amp, P.pulse, "chest")
		schedulePulse(0.18, "both", 1.00, 0.30)
		schedulePulse(0.40, "both", 0.95, 0.12)

	elseif style == "heal" then
		-- slow warm swell rather than an impact
		for i = 0, 5 do
			schedulePulse(i * 0.11, "both", 0.25 + i * 0.075, 0.09)
		end
		queueEvent("heal", 0.7, "chest")
	elseif style == "shield" then
		-- rising hum: steady ticks climbing in strength
		for i = 0, 7 do
			schedulePulse(i * 0.06, "both", 0.25 + i * 0.09, 0.05)
		end
		queueEvent("shield", 0.8, "chest")
	elseif style == "teleport" then
		-- sharp snap, silence, arrival thump
		dispatch("recoil", "both", 0.95, P.recoil, "chest")
		schedulePulse(0.28, "both", 1.00, 0.16)
	elseif style == "deploy" then
		-- mechanical double-click
		schedulePulse(0.00, weaponSrc(), 0.70, 0.05)
		schedulePulse(0.12, weaponSrc(), 0.55, 0.05)
		queueEvent("deploy", 0.6, "right_hand")
	elseif style == "buff" then
		-- firm confirmation pulse pair on both hands
		schedulePulse(0.00, "both", 0.75, 0.10)
		schedulePulse(0.16, "both", 0.95, 0.14)
		queueEvent("buff", 0.8, "chest")
	else
		dispatch("pulse", "both", 0.80, P.pulse, "chest")
	end
end

-- Fire the ability in a slot, honouring THAT ability's real cooldown.
function tryFireAbility(slot)
	local info = slotAbility[slot]
	if info == nil then
		if DEBUG_FIRES then logmsg(string.format("ability slot %d empty -- ignored", slot)) end
		return
	end
	local cd = slotCooldown[slot] or 0
	if cd > 0 then
		if DEBUG_FIRES then
			logmsg(string.format("ability %s still on cooldown (%.1fs left) -- ignored", info.key, cd))
		end
		return
	end
	playAbilityStyle(info.style)
	slotCooldown[slot] = info.cd
	logmsg(string.format("ability FIRED slot=%d %s style=%s cd=%ds",
		slot, info.key, info.style, info.cd))
end

local function tickAbilityCooldowns(delta)
	for i = 0, 5 do
		if slotCooldown[i] and slotCooldown[i] > 0 then
			slotCooldown[i] = slotCooldown[i] - delta
		end
	end
end

--=====================================================================
-- 1) Recoil / fire -> weapon hand   (now with gun-only RECOIL_STRENGTH)
--=====================================================================
--=====================================================================
-- Shared input state (declared before the recoil handler so it can see it)
--=====================================================================
local gButtons     = 0
local gLeftTrigger = 0
local gThumbRY     = 0
local prevButtonsLogged = 0
local prevModBits = ""

-- LT is the melee attack. The game rumbles when it lands, and that rumble must
-- go to the MELEE hand, not the weapon hand -- otherwise a left-hand sword swing
-- buzzes the right controller. The window keeps the routing correct for the
-- tail of the attack, after LT has already been released.
local MELEE_TRIGGER_THRESHOLD = 40     -- analog 0-255; ~15% pull counts as held
local MELEE_RUMBLE_WINDOW     = 1.20   -- seconds after LT release that rumble is still "melee"
local MELEE_HAND_IS_LEFT      = true   -- which hand swings the melee weapon
local ABILITY_SUPPRESS_ON_MELEE = true -- don't read a melee power attack's energy cost as a B-beam
local meleeWindow = 0.0

local function meleeSrc()
	return MELEE_HAND_IS_LEFT and leftSrc() or rightSrc()
end

local RECOIL_MIN_SPEED, RECOIL_COOLDOWN_TIME = 3000, 0.03
local recoilCooldown = 0.0
if RECOIL_ENABLED then
	callbacks.on_xinput_set_state(function(retval, user_index, vibration)
		pcall(function()
			if vibration == nil then return end
			local lo = vibration.wLeftMotorSpeed  or 0
			local hi = vibration.wRightMotorSpeed or 0
			local strongest = lo > hi and lo or hi
			if strongest >= RECOIL_MIN_SPEED and recoilCooldown <= 0 then
				local motorScale = clamp(strongest / 65535.0, 0.0, 1.0)
				local base = (P.recoil.amp + (1.0 - P.recoil.amp) * motorScale) * RECOIL_STRENGTH
				-- Melee rumble (LT) goes to the melee hand; gunfire to the weapon hand.
				local isMelee = (gLeftTrigger >= MELEE_TRIGGER_THRESHOLD) or (meleeWindow > 0)
				if isMelee then
					dispatch("swing", meleeSrc(), base, P.recoil,
						MELEE_HAND_IS_LEFT and "left_hand" or "right_hand")
				else
					dispatch("recoil", weaponSrc(), base, P.recoil, "right_hand")
				end
				recoilCooldown = RECOIL_COOLDOWN_TIME
			end
			vibration.wLeftMotorSpeed, vibration.wRightMotorSpeed = 0, 0
		end)
	end)
end

--=====================================================================
-- 2) Melee swing -> the hand that moved   [gold standard]
--=====================================================================
local SWING_THRESHOLD, SWING_MAX_SPEED, SWING_COOLDOWN = 50, 130, 0.20
-- Swinging one arm also drags the other hand through world space (shoulder/body
-- motion), and locomotion or turning moves BOTH hands together -- either can
-- push the idle hand over the threshold and buzz the wrong controller.
-- Two corrections:
--   1. Measure each hand relative to the HMD, so whole-body motion cancels out.
--   2. Dominance gate: if both hands cross the threshold at once, only the
--      clearly faster one fires. The other must reach SWING_DOMINANCE of the
--      faster hand's speed to count as its own independent swing.
local SWING_HMD_RELATIVE = true
local SWING_DOMINANCE    = 0.70   -- 0.0 = only ever one hand, 1.0 = gate off
local rightPos, rightRot = UEVR_Vector3f.new(), UEVR_Quaternionf.new()
local leftPos,  leftRot  = UEVR_Vector3f.new(), UEVR_Quaternionf.new()
local hmdPos,   hmdRot   = UEVR_Vector3f.new(), UEVR_Quaternionf.new()
local prevHmd  = { x = 0, y = 0, z = 0, init = false }
local prevRight = { x = 0, y = 0, z = 0, init = false }
local prevLeft  = { x = 0, y = 0, z = 0, init = false }
local rightSwingCd, leftSwingCd = 0.0, 0.0
-- Speed of a hand, optionally with the HMD's own displacement subtracted so
-- that walking, turning and body lean don't read as swings.
local function handSpeed(pos, prev, delta, hdx, hdy, hdz)
	if delta <= 0 then return 0 end
	local dx, dy, dz = pos.x - prev.x, pos.y - prev.y, pos.z - prev.z
	prev.x, prev.y, prev.z = pos.x, pos.y, pos.z
	if not prev.init then prev.init = true; return 0 end
	if hdx then dx, dy, dz = dx - hdx, dy - hdy, dz - hdz end
	return math.sqrt(dx*dx + dy*dy + dz*dz) * (1.0 / delta) * 10.0
end
local function swingAmp(speed)
	local range = SWING_MAX_SPEED - SWING_THRESHOLD
	local a = range > 0 and ((speed - SWING_THRESHOLD) / range) or 1.0
	return P.swing.amp + (0.95 - P.swing.amp) * clamp(a, 0.0, 1.0)
end

--=====================================================================
-- Input capture: buttons for reload (raw xinput, independent of remap order)
--=====================================================================
callbacks.on_xinput_get_state(function(retval, user_index, state)
	pcall(function()
		if state and state.Gamepad then
			gButtons = state.Gamepad.wButtons or 0
			gLeftTrigger = state.Gamepad.bLeftTrigger or 0
			gThumbRY = state.Gamepad.sThumbRY or 0
		end
	end)
end)

--=====================================================================
-- State trackers
--=====================================================================
local prevReload   = false
local prevReloadBtn = false
local reloadCd     = 0.0
local RELOAD_REFIRE_LOCK = 0.90   -- min seconds between reloads (covers the 2-stage sequence)
local reloadInsertTimer = 0.0
local reloadInsertArmed = false
local reloadAmmoAtEject = nil
local reloadPending     = false
local reloadConfirm     = 0.0
-- Damage: fraction of max health lost in one tick
local DAMAGE_MIN_FRAC = 0.003   -- low: armor chips are small fractions
local DAMAGE_MAX_FRAC = 0.250
local DAMAGE_COOLDOWN = 0.08
local chordPend    = nil
local chordTimer   = 0.0
local chordFired   = false
local prevB        = false
local prevY        = false
local beamCd       = 0.0
local pulseCd      = 0.0
local prevEnergy   = nil
local maxEnergy    = nil
local abilityCd    = 0.0
local prevAmmoR    = nil
local prevAmmoL    = nil
local gunfireCd    = 0.0
local prevDamageSig = ""
local prevHpPct    = nil
local prevPct      = nil
local prevIsDead   = nil
local deathLatched = false
local prevHealth   = nil
local prevArmorV   = nil
local prevArmorR   = nil
local maxArmor     = nil
local maxHealth    = nil
local damageCd     = 0.0
local wasFalling   = false
local airTime      = 0.0
local walkActive   = false
local walkStarted  = false
local walkStartTimer = 0.0
local walkStartFoot = "right"
local lastFoot     = "left"
local stepTimer    = 0.0
local hbTimer      = 0.0

--=====================================================================
-- Shared tick
--=====================================================================
callbacks.on_pre_engine_tick(function(engine, delta)
	if delta == nil then delta = 0 end
	if recoilCooldown > 0 then recoilCooldown = recoilCooldown - delta end
	-- LT held refreshes the melee window; released lets it decay.
	if gLeftTrigger >= MELEE_TRIGGER_THRESHOLD then
		meleeWindow = MELEE_RUMBLE_WINDOW
	elseif meleeWindow > 0 then
		meleeWindow = meleeWindow - delta
	end
	if rightSwingCd   > 0 then rightSwingCd   = rightSwingCd   - delta end
	if leftSwingCd    > 0 then leftSwingCd    = leftSwingCd    - delta end
	if abilityCd      > 0 then abilityCd      = abilityCd      - delta end
	if damageCd       > 0 then damageCd       = damageCd       - delta end
	if gunfireCd      > 0 then gunfireCd      = gunfireCd      - delta end
	if beamCd         > 0 then beamCd         = beamCd         - delta end
	tickPulseQueue(delta)
	tickAbilityCooldowns(delta)
	if pulseCd        > 0 then pulseCd        = pulseCd        - delta end
	if reloadCd       > 0 then reloadCd       = reloadCd       - delta end

	-- Melee (gold standard)
	local blockedMelee = (isMenu == true) or (isCinematic == true)
	if MELEE_ENABLED and not blockedMelee then
		pcall(function()
			vr.get_pose(vr.get_right_controller_index(), rightPos, rightRot)
			vr.get_pose(vr.get_left_controller_index(),  leftPos,  leftRot)

			-- HMD displacement this tick (used to cancel whole-body motion)
			local hdx, hdy, hdz = nil, nil, nil
			if SWING_HMD_RELATIVE and vr.get_hmd_index then
				local okh = pcall(function()
					vr.get_pose(vr.get_hmd_index(), hmdPos, hmdRot)
				end)
				if okh then
					if prevHmd.init then
						hdx = hmdPos.x - prevHmd.x
						hdy = hmdPos.y - prevHmd.y
						hdz = hmdPos.z - prevHmd.z
					else
						prevHmd.init = true
					end
					prevHmd.x, prevHmd.y, prevHmd.z = hmdPos.x, hmdPos.y, hmdPos.z
				end
			end

			local rSpeed = handSpeed(rightPos, prevRight, delta, hdx, hdy, hdz)
			local lSpeed = handSpeed(leftPos,  prevLeft,  delta, hdx, hdy, hdz)

			-- Dominance gate: the slower hand only counts as its own swing if it
			-- is within SWING_DOMINANCE of the faster hand. Otherwise it is just
			-- being dragged along by the arm that is actually swinging.
			local rOk, lOk = true, true
			if rSpeed >= SWING_THRESHOLD and lSpeed >= SWING_THRESHOLD then
				if rSpeed > lSpeed then
					lOk = (lSpeed >= rSpeed * SWING_DOMINANCE)
				elseif lSpeed > rSpeed then
					rOk = (rSpeed >= lSpeed * SWING_DOMINANCE)
				end
			end

			if rOk and rSpeed >= SWING_THRESHOLD and rightSwingCd <= 0 then
				dispatch("swing", rightSrc(), swingAmp(rSpeed), P.swing, "right_hand")
				rightSwingCd = SWING_COOLDOWN
			end
			if MELEE_BOTH_HANDS and lOk and lSpeed >= SWING_THRESHOLD and leftSwingCd <= 0 then
				dispatch("swing", leftSrc(), swingAmp(lSpeed), P.swing, "left_hand")
				leftSwingCd = SWING_COOLDOWN
			end
		end)
	end

	local pawn = nil
	pcall(function() pawn = api:get_local_pawn(0) end)
	local mode = readMovementMode(pawn)
	local grounded = (mode == MOVE_WALKING) or (mode == MOVE_NAVWALK)
	local sprinting = readBoolProp(pawn, "ISprint") == true

	-- Primary weapon actor, fetched once: used by both the reload insert
	-- detection (ammo refill) and the gunfire detection (ammo drop).
	local wep = nil
	if pawn ~= nil then pcall(function() wep = pawn.RightWeaponActor end) end

	----------------------------------------------------------------
	-- Reload: driven by ENGINE state, not the button.
	----------------------------------------------------------------
	-- Eject  = SHTerminator.GetIsInReload() rising edge (authoritative start).
	-- Insert = SHDistanceWeapon.currentAmmo increasing -- the exact frame the
	--          new magazine seats, so the second buzz lands on the real event
	--          instead of a guessed delay.
	-- The X button and a timed fallback remain only for when those reads fail.
	if RELOAD_ENABLED then
		local g2        = callBool(pawn, "GetIsInReload")
		local reflected = (g2 == true)
		local haveEngineSignal = (g2 ~= nil)
		local btnDown   = (gButtons & RELOAD_BUTTON_MASK) ~= 0

		-- start of reload
		local rose
		if haveEngineSignal and RELOAD_USE_ENGINE_EVENTS then
			rose = reflected and not prevReload          -- engine only; ignore button
		else
			rose = (reflected and not prevReload) or (btnDown and not prevReloadBtn)
		end

		-- A press that CAN'T reload (magazine already full, or no spare mags)
		-- still blips the engine reload flag, which is why the buzz fired on
		-- every X press. Check the weapon can actually reload before arming.
		local canReload = true
		if wep ~= nil then
			local ammo = readNum(wep, "currentAmmo")
			local cap  = readNum(wep, "AmmoPerMagazine")
			local mags = readNum(wep, "CurrentMagazineNumber")
			local inf  = readBoolProp(wep, "InfiniteMagazine")
			if ammo ~= nil and cap ~= nil and cap > 0 and ammo >= cap then
				canReload = false                       -- already full
			elseif inf ~= true and mags ~= nil and mags <= 0 then
				canReload = false                       -- no magazines left
			end
		end

		-- Arm on the rising edge, but don't buzz yet: the reload state must
		-- persist for RELOAD_CONFIRM_TIME to prove it wasn't a momentary blip.
		if rose and reloadCd <= 0 and canReload then
			reloadPending = true
			reloadConfirm = RELOAD_CONFIRM_TIME
			if DEBUG_FIRES then logmsg("reload armed (confirming...)") end
		elseif rose and not canReload then
			if DEBUG_FIRES then logmsg("reload press ignored (mag full or no spare mags)") end
		end

		if reloadPending then
			if not reflected and haveEngineSignal and RELOAD_USE_ENGINE_EVENTS then
				reloadPending = false                   -- aborted before confirming
				if DEBUG_FIRES then logmsg("reload aborted before confirm") end
			else
				reloadConfirm = reloadConfirm - delta
				if reloadConfirm <= 0 then
					reloadPending = false
					if RELOAD_TWO_STAGE then
						dispatch("reload_eject", weaponSrc(), nil, P.reload_eject, "right_hand")
						-- Arm the timed fallback with the weapon's REAL reload time;
						-- the ammo-refill watcher below normally beats it.
						local rt = nil
						if wep ~= nil then rt = readNum(wep, "ReloadTime") end
						reloadInsertTimer = (rt and rt > 0.05) and (rt * RELOAD_INSERT_TIME_SCALE)
						                    or RELOAD_INSERT_DELAY
						reloadInsertArmed = true
						reloadAmmoAtEject = (wep ~= nil) and readNum(wep, "currentAmmo") or nil
						logmsg(string.format("reload eject (src=%s, insert fallback %.2fs)",
							haveEngineSignal and "engine" or "button", reloadInsertTimer))
					else
						dispatch("reload", weaponSrc(), P.reload.amp, P.reload, "right_hand")
						logmsg("reload fired")
					end
					reloadCd = RELOAD_REFIRE_LOCK
				end
			end
		end
		prevReload    = reflected
		prevReloadBtn = btnDown
	end

	-- Second stage: fires when the magazine ACTUALLY seats.
	-- Primary signal: currentAmmo increases (deterministic, frame-accurate).
	-- Fallback: the armed timer, in case the weapon/ammo read is unavailable.
	if reloadInsertArmed then
		local seated = false
		local nowAmmo = (wep ~= nil) and readNum(wep, "currentAmmo") or nil
		if nowAmmo ~= nil and reloadAmmoAtEject ~= nil and nowAmmo > reloadAmmoAtEject then
			seated = true
		end
		reloadInsertTimer = reloadInsertTimer - delta
		if seated or reloadInsertTimer <= 0 then
			dispatch("reload_insert", weaponSrc(), nil, P.reload_insert, "right_hand")
			reloadInsertArmed = false
			logmsg(seated and "reload insert (ammo refill)" or "reload insert (timer fallback)")
		end
	end

	----------------------------------------------------------------
	-- Abilities: slot-aware, per-ability cooldowns and haptic styles
	----------------------------------------------------------------
	-- PowerDiag showed GetCurrentPowerComponent() tracks the SELECTED power,
	-- not a cast, so there is no poll-based "it fired" signal (firing the same
	-- ability twice would look identical). Instead: read which ability occupies
	-- each slot via GetPsyPowerComponentForSlot(), then on a button press use
	-- THAT ability's real cooldown and its own haptic style. This works for all
	-- classes automatically, since the slots are read at runtime.
	if ABILITY_ENABLED then
		slotRefresh = slotRefresh - delta
		if slotRefresh <= 0 then
			slotRefresh = ABILITY_SLOT_REFRESH
			refreshAbilitySlots(pawn)
		end

		-- Stick gesture (primary on this profile) OR face-button mask (secondary)
		local stickUp, stickDown = false, false
		if ABILITY_USE_RIGHT_STICK then
			stickUp   = gThumbRY >  ABILITY_STICK_THRESHOLD
			stickDown = gThumbRY < -ABILITY_STICK_THRESHOLD
		end
		local yDown = stickUp   or ((gButtons & ABILITY_Y_MASK) ~= 0)
		local bDown = stickDown or ((gButtons & ABILITY_B_MASK) ~= 0)

		if ABILITY_THIRD_CHORD then
			-- B+Y together = third ability. Hold a lone press briefly to see if
			-- the other button joins, so a chord never leaks a single-ability buzz.
			if bDown and yDown then
				if not chordFired then
					tryFireAbility(ABILITY_SLOT_FOR_A)
					chordFired = true
					chordPend  = nil          -- cancel any pending single
				end
			else
				-- start a pending single on a fresh rising edge
				if yDown and not prevY and chordPend == nil and not chordFired then
					chordPend, chordTimer = ABILITY_SLOT_FOR_Y, ABILITY_CHORD_WINDOW
				elseif bDown and not prevB and chordPend == nil and not chordFired then
					chordPend, chordTimer = ABILITY_SLOT_FOR_B, ABILITY_CHORD_WINDOW
				end
				-- resolve a pending single once the window closes
				if chordPend ~= nil then
					chordTimer = chordTimer - delta
					if chordTimer <= 0 then
						tryFireAbility(chordPend)
						chordPend = nil
					end
				end
			end
			-- both released: re-arm
			if not bDown and not yDown then chordFired = false end
		else
			if yDown and not prevY then tryFireAbility(ABILITY_SLOT_FOR_Y) end
			if bDown and not prevB then tryFireAbility(ABILITY_SLOT_FOR_B) end
		end
		prevB, prevY = bDown, yDown
	end

	----------------------------------------------------------------
	-- Gunfire: currentAmmo drop on the weapon actor (works with in-game
	-- controller rumble DISABLED, unlike the rumble-based recoil path).
	----------------------------------------------------------------
	if GUNFIRE_ENABLED and pawn ~= nil then
		local function checkWeapon(actorProp, src, loc, prevKey)
			local wep
			local ok = pcall(function() wep = pawn[actorProp] end)
			if not ok or wep == nil then return nil end
			local ammo = readNum(wep, "currentAmmo")
			if ammo == nil then return nil end
			local prev = (prevKey == "R") and prevAmmoR or prevAmmoL
			if prev ~= nil and ammo < prev and gunfireCd <= 0 then
				-- ignore the jump back up on reload; only count downward steps
				local shots = prev - ammo
				local cap = readNum(wep, "AmmoPerMagazine") or 0
				if shots > 0 and (cap <= 0 or shots < cap) then
					dispatch("recoil", src, P.recoil.amp, P.recoil, loc)
					gunfireCd = GUNFIRE_COOLDOWN
					logmsg(string.format("gunfire %s ammo %d->%d", prevKey, prev, ammo))
				end
			end
			return ammo
		end

		local a = checkWeapon("RightWeaponActor", weaponSrc(), "right_hand", "R")
		if a ~= nil then prevAmmoR = a end
		if GUNFIRE_LEFT_HAND then
			local b = checkWeapon("LeftWeaponActor", leftSrc(), "left_hand", "L")
			if b ~= nil then prevAmmoL = b end
		end
	end

	----------------------------------------------------------------
	-- Damage taken: Terminators absorb hits on ARMOR before Health moves at all,
	-- so polling Health alone misses most damage. Watch health, armor value and
	-- armor ratio; any downward step counts as a hit. Verified in dump:
	--   SHCharac.Health (Float), InitialHealth (Float),
	--   SHCharac.ArmorValue (Int), SHCharac.ArmorRatio (Float)
	----------------------------------------------------------------
	if DAMAGE_ENABLED and pawn ~= nil then
		-- Health / ArmorValue / ArmorRatio were PROVEN STATIC on this build
		-- (100.0 / 60 / 0.05 through hits AND death), so they are no longer read
		-- at all -- that removes 3 reflection calls per tick for no loss.
		-- GetOnFloorBeforeDeath() was likewise proven useless (true while alive,
		-- false at death) and is no longer read.
		local hpPct = nil
		do  -- GetHealthPercentage(CleverAverage, Average) takes two bools
			local ok, v = pcall(function() return pawn:GetHealthPercentage(false, false) end)
			if ok and type(v) == "number" then hpPct = v end
		end

		if DEBUG_DAMAGE then
			local sig = tostring(hpPct)
			if sig ~= prevDamageSig then
				logmsg("POOLS hpPct=" .. sig)
				prevDamageSig = sig
			end
		end

		-- DEATH: hpPct dropping from a live value to 0 (proven in the death log).
		-- SHTerminator.isDead is read as a confirming/secondary signal.
		local pctNow = hpPct
		if pctNow ~= nil and pctNow > 1.5 then pctNow = pctNow / 100.0 end
		local isDeadProp = readBoolProp(pawn, "isDead")

		local justDied = false
		if pctNow ~= nil and prevPct ~= nil and prevPct > 0.05 and pctNow <= 0.001 then
			justDied = true
		elseif isDeadProp == true and prevIsDead ~= true then
			justDied = true
		end

		if justDied and not deathLatched then
			dispatch("death", "both", P.death.amp, P.death, "chest")
			deathLatched = true
			if DEBUG_LOG then
				logmsg(string.format("DEATH (hpPct %s->%s, isDead=%s)",
					tostring(prevPct), tostring(pctNow), tostring(isDeadProp)))
			end
		end
		if pctNow ~= nil and pctNow > 0.05 and isDeadProp ~= true then
			deathLatched = false
		end
		if isDeadProp ~= nil then prevIsDead = isDeadProp end
		prevPct = pctNow

		-- DAMAGE: health-percentage drop. Transitions into/out of 0 are the
		-- death/respawn case and must not register as a max-strength hit.
		local frac, a, b = 0.0, prevHpPct, hpPct
		if a ~= nil and b ~= nil then
			if a > 1.5 then a = a / 100.0 end
			if b > 1.5 then b = b / 100.0 end
			if a > 0.001 and b > 0.001 then frac = a - b end
		end

		if frac >= DAMAGE_MIN_FRAC and damageCd <= 0 then
			local amt = clamp((frac - DAMAGE_MIN_FRAC) / (DAMAGE_MAX_FRAC - DAMAGE_MIN_FRAC), 0.0, 1.0)
			dispatch("damage", "both", P.damage.amp + (1.0 - P.damage.amp) * amt, P.damage, "chest")
			damageCd = DAMAGE_COOLDOWN
			if DEBUG_LOG then
				logmsg(string.format("damage frac=%.3f (hpPct %.3f->%.3f)", frac, a, b))
			end
		end

		if hpPct ~= nil then prevHpPct = hpPct end
	end

	----------------------------------------------------------------
	-- Landing: Falling -> grounded (both hands)
	----------------------------------------------------------------
	if LAND_ENABLED and mode ~= nil then
		if mode == MOVE_FALLING then
			wasFalling = true
			airTime = airTime + delta
		else
			if wasFalling and grounded and airTime >= LAND_MIN_AIR then
				local a = clamp((airTime - LAND_MIN_AIR) / (LAND_MAX_AIR - LAND_MIN_AIR), 0.0, 1.0)
				dispatch("land", "both", P.land.amp + (1.0 - P.land.amp) * a, P.land, "feet")
				logmsg(string.format("land fired (air=%.2fs)", airTime))
			end
			wasFalling = false
			airTime = 0.0
		end
	end

	----------------------------------------------------------------
	-- Walking: per-direction cadence, with start foot + start delay
	----------------------------------------------------------------
	if WALK_ENABLED then
		local x, y, mag = leftStickXY()
		if grounded and mag > WALK_DEADZONE then
			local pat = sprinting and SPRINT_PATTERN or (WALK_DIRS[classifyDir(x, y)] or WALK_DIRS.forward)
			if not walkActive then
				-- movement just started: arm the start delay + capture the start foot
				walkActive = true
				walkStarted = false
				walkStartTimer = pat.startDelay or 0.0
				walkStartFoot = pat.startFoot or "right"
			end
			local footSrc = function(f) return (f == "right") and rightSrc() or leftSrc() end
			if not walkStarted then
				walkStartTimer = walkStartTimer - delta
				if walkStartTimer <= 0 then
					dispatch("footstep", footSrc(walkStartFoot), pat.amp, P.footstep, "feet")
					lastFoot = walkStartFoot
					stepTimer = pat.interval
					walkStarted = true
				end
			else
				stepTimer = stepTimer - delta
				if stepTimer <= 0 then
					local nextFoot = (lastFoot == "right") and "left" or "right"
					dispatch("footstep", footSrc(nextFoot), pat.amp, P.footstep, "feet")
					lastFoot = nextFoot
					stepTimer = pat.interval   -- picks up the current direction's interval
				end
			end
		else
			walkActive = false
			walkStarted = false
			stepTimer = 0.0
		end
	end

	----------------------------------------------------------------
	-- Debug
	----------------------------------------------------------------
	-- Ability-input diagnostic: ControlInput.lua rewrites the pad state, so the
	-- bit an ability sends may be stripped before this script reads it. Log BOTH
	-- what we see (gButtons) and the mod's own button globals, which are sampled
	-- at a different point in the callback chain. Whichever source shows a change
	-- when an ability fires is the one to trigger on.
	if DEBUG_BUTTONS then
		local modBits = string.format("Y=%s B=%s X=%s A=%s",
			tostring(Ybutton), tostring(Bbutton), tostring(Xbutton), tostring(Abutton))
		if gButtons ~= prevButtonsLogged or modBits ~= prevModBits then
			logmsg(string.format("INPUT buttons=0x%04X  mod[%s]  RY=%d",
				gButtons, modBits, gThumbRY))
			prevButtonsLogged = gButtons
			prevModBits = modBits
		end
	end
	if DEBUG_HEARTBEAT then
		hbTimer = hbTimer + delta
		if hbTimer >= HEARTBEAT_PERIOD then
			hbTimer = 0.0
			logmsg(string.format("hb pawn=%s hp=%s armorV=%s armorR=%s movemode=%s sprint=%s stick=%.2f energy=%s rel1=%s rel2=%s",
				tostring(pawn ~= nil),
				tostring(readNum(pawn, "Health")),
				tostring(readNum(pawn, "ArmorValue")),
				tostring(readNum(pawn, "ArmorRatio")),
				tostring(mode), tostring(sprinting), leftStickMag(),
				tostring(readNum(pawn, "fCurrentPsyEnergy")),
				tostring(callBool(pawn, "GetIsReloadingweapon")),
				tostring(callBool(pawn, "GetIsInReload"))))
		end
	end

	flushEvents()
end)

-- Start each session with a fresh event file (the bridge tails from the end,
-- so old lines are never replayed, but this stops unbounded growth).
if EMIT_EVENTS and EMIT_TRUNCATE_ON_LOAD then
	pcall(function()
		local f = io.open(EMIT_PATH, "w")
		if f then f:close() end
	end)
end

logmsg("loaded")