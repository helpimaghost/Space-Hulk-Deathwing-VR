require(".\\Subsystems\\MeleePower")

require(".\\Subsystems\\GlobalData")
--require(".\\Subsystems\\GlobalCustomData")
require(".\\Subsystems\\HelperFunctions")
--require(".\\Subsystems\\test")
 
local function CinematicStatus(pawn)
	if pawn ==nil then return end
	if not UEVR_UObjectHook.exists(CameraManager) then
--	if CameraManager.ViewTarget==nil then
		CameraManager= UEVR_UObjectHook.get_first_object_by_class(CameraManager_C)
	end
 	if CameraManager.ViewTarget.Target ~= pawn then
		isCinematic=true
		--UEVR_UObjectHook.set_disabled(true)
	else isCinematic=false
		if not isMenu then
		--	UEVR_UObjectHook.set_disabled(false)
		end
	end
	--print(isCinematic)
end 




-- UEVR mod values are strings. get uses colon syntax, set uses dot syntax.
-- get can return trailing characters, so compare the prefix, as uevr_utils does.
local function getModBool(name)
	local ok, v = pcall(function() return uevr.params.vr:get_mod_value(name) end)
	if not ok or v == nil then return nil end
	return string.sub(v, 1, 4) == "true"
end

local function setModBool(name, value)
	pcall(function() uevr.params.vr.set_mod_value(name, value and "true" or "false") end)
end

local menuStateLast   = nil   -- nil = not yet evaluated
local followViewSaved = nil   -- UI_FollowView as it was before the menu opened

local function MenuStatus(Player)
	if Player == nil then return end

	local inMenu = Player.bShowMouseCursor and true or false
	isMenu = inMenu

	-- Edge-triggered. The old code wrote UI_FollowView in both branches on every
	-- tick, so the value could not be changed from the UEVR overlay or by any
	-- other script: whatever you set was overwritten on the following frame.
	if menuStateLast == nil then
		-- First evaluation. Only act if we started inside a menu, so a saved
		-- UI_FollowView value is not clobbered at load.
		if inMenu then
			followViewSaved = getModBool("UI_FollowView")
			setModBool("UI_FollowView", false)
		end
		menuStateLast = inMenu
	elseif inMenu ~= menuStateLast then
		if inMenu then
			-- Entering a menu: remember the current value, then world-lock the panel.
			followViewSaved = getModBool("UI_FollowView")
			setModBool("UI_FollowView", false)
		else
			-- Leaving a menu: restore what was there, not a hardcoded true.
			local restore = followViewSaved
			if restore == nil then restore = true end
			setModBool("UI_FollowView", restore)
			followViewSaved = nil
		end
		menuStateLast = inMenu
	end

	if inMenu then
		if not wasRecentered then
			vr.recenter_view()
			wasRecentered = true
		end
	else
		wasRecentered = false
	end
end
 
local function SprintRoll(state,cpawn)
	if isThumbMotion and math.abs(StickR.y) < 0.2 then
		isThumbMotion=false
		SendKeyUp("0x20")
			SendKeyUp("C")
	end
		
	
	--print(StickR.x)
	--print(StickR.y)
	if not isMenu and not TactiNavVisible then 
		if StickR.y>0.8 and not isThumbMotion then
			SendKeyDown("0x20")
			
			isThumbMotion=true
		elseif StickR.y<-0.8 and not isThumbMotion then
			isThumbMotion=true
			SendKeyDown("C")
			WpnLocationUpdate=true
			WpnUpdateDelta=0
		--	pressButton(state, XINPUT_GAMEPAD_B)
		--	pawn:InpActEvt_Crouch_K2Node_InputActionEvent_13(Key)
		
		end
		
		
		
		
	end
	if cpawn~=nil  then
		
		
		if Abutton and cpawn.CharacterMovement~=nil and not isSprinting and canPressA then
			canPressA=false
			isSprinting=true
			cpawn.CharacterMovement.MaxWalkSpeed = 580 
			cpawn.CharacterMovement.MaxWalkSpeedCrouched = 240
		elseif ((Abutton and canPressA) or math.abs(ThumbLY)<20000) and isSprinting and cpawn.CharacterMovement~=nil then
			isSprinting=false
			canPressA=false
			cpawn.CharacterMovement.MaxWalkSpeed = 280
			cpawn.CharacterMovement.MaxWalkSpeedCrouched = 140
		end
	end
	if not Abutton then
			canPressA=true
	end
	
	
	
end

WasReloadPressed =false

-- Globals that GlobalData.lua does not seed. Without these, the first read
-- of each is a nil arithmetic/compare error.
ThumbCount   = ThumbCount   or 0
ThumbCountl  = ThumbCountl  or 0
ResetDelta   = ResetDelta   or 0
VRClock      = VRClock      or 0

local function CollisionFunctionExecute(state,pawn)
	--local MeshArray1 = pawn.Children
	
	--checkMaterial(pawn,MeshArray1,"FOV_Alpha") --from FOV FIXER
	if pressY then
		--unpressButton(state,XINPUT_GAMEPAD_RIGHT_SHOULDER)
		pressButton(state,XINPUT_GAMEPAD_Y)
		if not rShoulder then
			pressY=false
		end
	end
	
	if ReloadInProgress  then
		--WasReloadPressed=true
		--SendKeyDown("R")
		--ReloadCount=ReloadCount+delta
	else --SendKeyUp("R")
	end
	-- EDIT COLLISION BODY BOXES:
	
	if pressRS then
		--pressButton(state,XINPUT_GAMEPAD_DPAD_UP)
		SendKeyDown("1")
		if not lShoulder and not rShoulder then
			pressRS=false
			--SendKeyDown("1")
			SendKeyUp("1")
			
		end
	end
	if pressLS and not rShoulder then
		SendKeyDown("0x09")
		--print("pressed2")
		--pressLS=false
		--pressButton(state,XINPUT_GAMEPAD_DPAD_DOWN)
		if not lShoulder and not rShoulder then
			pressLS=false
			--SendKeyDown("2")
			SendKeyUp("0x09")
		end
	end
	if pressLS and not lShoulder then
		SendKeyDown("2")
		--print("pressed2")
		--pressLS=false
		--pressButton(state,XINPUT_GAMEPAD_DPAD_DOWN)
		if not lShoulder and not rShoulder then
			pressLS=false
			--SendKeyDown("2")
			SendKeyUp("2")
		end
	end
	if pressLH then
		SendKeyDown("G")
		--pressButton(state,XINPUT_GAMEPAD_DPAD_DOWN)
		if not lShoulder and not rShoulder then
			pressLH=false
			--SendKeyDown("2")
			SendKeyUp("G")
		end
	end
	if pressRH then
		SendKeyDown("3")
		--pressButton(state,XINPUT_GAMEPAD_DPAD_RIGHT)
		if not lShoulder and not rShoulder then
			pressRH=false
			--SendKeyDown("3")
			SendKeyUp("3")
		end
	end
	if pressRC then
		--pressButton(state,XINPUT_GAMEPAD_DPAD_LEFT)
		SendKeyDown("4")
		if not lShoulder and not rShoulder then
			pressRC=false
			--SendKeyDown("4")
			SendKeyUp("4")
		end
	end
end
local wasMouseRight= false
local LTriggerLast=false
local rShoulderLast=false
local ThumbCount= 0

-------------------------------------------------------------------
-- SWING MELEE
--   swing alone          -> Light Attack  (short synthetic LT tap)
--   swing while LT held  -> Heavy Attack  (long synthetic LT hold)
-- LT is never passed through to the game; it is only read as a modifier.
-------------------------------------------------------------------
local MELEE_ON    = 43     -- PosDiffSecondaryHand needed to start a swing
local MELEE_OFF   = 20     -- must drop below this before another swing arms
local LIGHT_HOLD  = 0.12   -- seconds: tap length, and the late-squeeze window
local HEAVY_HOLD  = 0.55   -- seconds: charge length, must exceed game's threshold
local MELEE_CD    = 0.25   -- seconds: lockout, guarantees a clean release edge
local MELEE_DEBUG = true   -- set false once tuned

local mState  = "idle"
local mT0     = 0
local mHeavy  = false
local mArmed  = true

function UpdateInput(state,cpawn)

--Read Gamepad stick input 
	ThumbLX = state.Gamepad.sThumbLX
	ThumbLY = state.Gamepad.sThumbLY
	ThumbRX = state.Gamepad.sThumbRX
	ThumbRY = state.Gamepad.sThumbRY
	LTrigger= state.Gamepad.bLeftTrigger
	RTrigger= state.Gamepad.bRightTrigger
	rShoulder= isButtonPressed(state, XINPUT_GAMEPAD_RIGHT_SHOULDER)
	lShoulder= isButtonPressed(state, XINPUT_GAMEPAD_LEFT_SHOULDER)
	lThumb   = isButtonPressed(state, XINPUT_GAMEPAD_LEFT_THUMB)
	rThumb   = isButtonPressed(state, XINPUT_GAMEPAD_RIGHT_THUMB)
	Abutton  = isButtonPressed(state, XINPUT_GAMEPAD_A)
	Bbutton  = isButtonPressed(state, XINPUT_GAMEPAD_B)
	Xbutton  = isButtonPressed(state, XINPUT_GAMEPAD_X)
	Ybutton  = isButtonPressed(state, XINPUT_GAMEPAD_Y)
	DPAD_Up   =isButtonPressed(state, XINPUT_GAMEPAD_DPAD_UP)
	DPAD_Right=isButtonPressed(state, XINPUT_GAMEPAD_DPAD_RIGHT)
    DPAD_Left =isButtonPressed(state, XINPUT_GAMEPAD_DPAD_LEFT)
	DPAD_Down =isButtonPressed(state, XINPUT_GAMEPAD_DPAD_DOWN)
	vr.get_joystick_axis(vr.get_right_joystick_source(), StickR)
	if not isCinematic and not isMenu then
		--unpressButton(state,XINPUT_GAMEPAD_RIGHT_SHOULDER)
		--unpressButton(state,XINPUT_GAMEPAD_LEFT_SHOULDER)
		--unpressButton(state,XINPUT_GAMEPAD_X)
		state.Gamepad.bLeftTrigger=0
	end
	--print(PosDiffSecondaryHand)

	-- ---- Swing melee state machine ----------------------------------
	local spd = PosDiffSecondaryHand or 0
	local now = VRClock or 0

	if spd < MELEE_OFF then mArmed = true end

	local meleeOK = not isCinematic and not isMenu and not lShoulder

	if mState == "idle" then
		if mArmed and meleeOK and spd > MELEE_ON then
			mState = "pressing"
			mT0    = now
			mArmed = false
			mHeavy = LTrigger > 0
		end

	elseif mState == "pressing" then
		local held = now - mT0
		-- squeezing LT slightly after the swing begins still counts as heavy
		if not mHeavy and held < LIGHT_HOLD and LTrigger > 0 then
			mHeavy = true
		end
		if held >= (mHeavy and HEAVY_HOLD or LIGHT_HOLD) then
			if MELEE_DEBUG then
				print(string.format("MELEE %s  held=%.3f  peakSpd=%.1f",
					mHeavy and "HEAVY" or "light", held, spd))
			end
			mState = "cooldown"
			mT0    = now
		end

	elseif mState == "cooldown" then
		if now - mT0 > MELEE_CD then mState = "idle" end
	end

	if mState == "pressing" then
		state.Gamepad.bLeftTrigger = 255
	end
	-- -----------------------------------------------------------------
	
	if rThumb then
		ThumbCount = ThumbCount + 1
	else ThumbCount = 0
	end
	-- cpawn is nil during menus, level loads and cinematics. Indexing it here
	-- threw hundreds of times a second on the input path.
	local torso = cpawn and cpawn.Torso or nil
	if torso ~= nil then
		if torso.bForceRefpose == false then
			torso.bForceRefpose = true
		end
		if ThumbCount > 200 then
			torso.bForceRefpose = false
		end
	end
	if lThumb then
		ThumbCountl = ThumbCountl + 1
	else ThumbCountl = 0
	end
	if ThumbCountl > 200 then
		pressButton(state,XINPUT_GAMEPAD_START)
	end
	if TactiNavVisible then
		state.Gamepad.sThumbRX=0
	    state.Gamepad.sThumbRY=0
	end
	
	if DPAD_Up   
	   or DPAD_Right
	   or DPAD_Left 
	   or DPAD_Down
		then
		WpnSwitch=true
		ChangeReq=true
	end
	if LTrigger == 0 then
	 WasReloadPressed=false
	end
	
	-- Edge-triggered. This previously dispatched a synthetic mouse-down through
	-- LUAKEY.dll on every poll that LB was held. `canChange` is never assigned
	-- anywhere in the project, so `not canChange` was always true and the guard
	-- did nothing. Kept in the condition to preserve the original intent if it
	-- ever gets wired up.
	if lShoulder and not canChange then
		if not wasMouseRight then
			SendKeyDown("0x02")
			wasMouseRight = true
		end
	elseif wasMouseRight then
		SendKeyUp("0x02")
		wasMouseRight = false
	end
	--if  GetHandDistance() <=10 and lShoulder and rShoulder then
	--	pressButton(state,XINPUT_GAMEPAD_LEFT_SHOULDER)
		--pressButton(state,XINPUT_GAMEPAD_RIGHT_SHOULDER)
	--end
	if Xbutton and PosDiffWeaponHand > 30 then
		--pressButton(state,XINPUT_GAMEPAD_RIGHT_THUMB)
	end
	
	
--	SprintRoll(state,cpawn)	
--	CollisionFunctionExecute(state,cpawn)
	--print(PosDiffWeaponHand)
--	print(pressLS)
	
	if LTrigger~=LTriggerLast or rShoulder~=rShoulderLast then
	WpnLocationUpdate=true 	
	WpnUpdateDelta=0
	end 
	LTriggerLast=LTrigger
	rShoulderLast=rShoulder
end





uevr.sdk.callbacks.on_xinput_get_state(
function(retval, user_index, state)
	-- This callback fires once per controller index the game polls. Games that
	-- scan for a connected pad poll 0-3 every frame, which ran UpdateInput four
	-- times per frame and let the zeroed state of pads 1-3 overwrite the input
	-- globals that CameraManager and MeleePower read.
	if user_index ~= 0 then return end

	local dpawn = api:get_local_pawn(0)
	UpdateInput(state, dpawn)
end)

local last_level=nil
local engine =nil
local function OnLevelChange()
		if engine==nil then
			engine = game_engine_class:get_first_object_matching(false)
		end
		if not engine then
			return
		end
	
		local viewport = engine.GameViewport
	
		if viewport then
			 world = viewport.World
	
			if world then
				local level = world.PersistentLevel
	
				if last_level ~= level then					
					
					right_hand_component=nil
					left_hand_component=nil	
					
					engine=nil
					ResetDelta=0
					GlockMesh =nil
					BinoMesh=nil
					CurrentWeaponMesh=nil
					HandSceneComp=nil
					Cam=nil
					
					BodyVisibilityChecked=false
					isReloading=false
					WpnMatArray={}
					ReloadInProgress=false
					
					Cursor=nil
				InitCount =0
				Init= false
				
				
					dpawn=nil
					Player=nil

						
				end
	
				last_level = level
			end
		end
end
local ReloadCount=0
local MagCheckCount=0
local tTickCount=0
local InitiateQuickDrop=false
 WantsMagCheck=false
local function HandleReloadMagcheck(ddelta)
		
		if not ReloadMontage then
			if ReloadInProgress  then
				CheckInitiated=true
			--SendKeyDown("R")
				ReloadCount=ReloadCount+ddelta
			end 
			if not ReloadInProgress and CheckInitiated then
				if ReloadCount<=0.25 then
					WantsMagCheck=true
					ReloadCount=0
					CheckInitiated=false
				else 
					ReloadCount=0
					CheckInitiated=false
					WasReloadPressed=False
				end
			end				
		
		
		
			if ReloadCount> 0.25 and not WasReloadPressed then 
				SendKeyDown("R")
				WasReloadPressed=true
			else
				SendKeyUp("R")
				--WantsMagCheck=false			
			end
			--ReloadCount=0
			if rThumb and not InitiateQuickDrop then
				InitiateQuickDrop=true
			end
			
			if WantsMagCheck then
				if MagCheckCount<2 then
					MagCheckCount=MagCheckCount+ddelta
					SendKeyDown("R")
				
				else SendKeyUp("R")
					MagCheckCount=0
					WantsMagCheck=false
				end
				
			end
		end
		if InitiateQuickDrop then
				if (tTickCount >=0 and tTickCount<5) or (tTickCount >=8 and tTickCount<11) then
					SendKeyDown("R")
					tTickCount=tTickCount+1
				elseif (tTickCount >=5 and tTickCount<7) or (tTickCount >= 11 and tTickCount<15) then
					tTickCount=tTickCount+1
					SendKeyUp("R")
				else 
					tTickCount=tTickCount+1
					--SendKeyUp("R")
				end
				if tTickCount >20 then
					tTickCount=0
					SendKeyUp("R")
					InitiateQuickDrop=false
				end
				--print(tTickCount)
		end
		
		
end


function MeshAttach(dpawn)
	if dpawn== nil then return  end
	
	if dpawn.RArm then
		UEVR_UObjectHook.UEVR_UObjectHook.get_or_add_motion_controller_state(PMesh):set_hand(1)
		print(neededPitch)
		UEVR_UObjectHook.UEVR_UObjectHook.get_or_add_motion_controller_state(PMesh):set_rotation_offset(Vector3d.new(-neededPitch*math.pi/180,math.pi/2,0))
	end
end



uevr.sdk.callbacks.on_pre_engine_tick(
	function(engine, delta)
	-- Single monotonic clock for the melee state machine. Nothing else in the
	-- project ever wrote VRClock, so every held-duration test evaluated to 0.
	VRClock = VRClock + (delta or 0)
	--if dpawn==nil then 
	local	pawn=api:get_local_pawn(0)	
	--end
	
	local Player=api:get_player_controller(0)	
	--Player.bShowMouseCursor=true
		OnLevelChange()
		
		--HandleReloadMagcheck(delta)
				
		if dpawn~=nil then
		--	MeshAttach(pawn)
		end
		
		
		if ResetDelta<5 then
			ResetDelta = ResetDelta+delta
		else WasReset=false
		end
		--CustomInput(dpawn,delta)
		--CinematicStatus(pawn)
		MenuStatus(Player)
	--	SetMouseLocation(Player)
	---	OperateTactiNav() 
		--print(BodyVisibilityChecked)
		if  BodyVisibilityChecked ==false  then
			--	print("ok")
		--	CheckBodyVisibility(dpawn)
			--BodyVisibilityChecked=true
		end
	--	UpdateHandsVisByMontage(dpawn)
		--if HandSceneComp~=nil then
		--	local CounterPitch= dpawn.Controller.ControlRotation.Pitch
		--	HandSceneComp.RelativeRotation.Roll=CounterPitch
		--end
end)