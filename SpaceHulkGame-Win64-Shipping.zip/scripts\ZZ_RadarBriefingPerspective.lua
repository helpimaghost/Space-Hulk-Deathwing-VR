--[[
ZZ_RadarBriefingPerspective.lua (v2)
-----------------------------------------------------------------
Two jobs:

1. PERSPECTIVE (v1 behaviour, retained)
   Force VR_DecoupledPitch = false while the Radar Briefing view is
   active, so UEVR stops discarding the tactical camera's downward
   pitch. Ported from the one working lever in the VOID/BREAKER
   MenusGUICursor.lua.

2. UI OVERRIDE (new)
   UIPeek.lua keeps the UEVR UI panel + game HUD widgets hidden by
   default, revealed only on thumbrest/RB. That is right in gameplay
   and wrong in menus. This script detects the four "menu-ish" states
   and forces the UI permanently peeked for their duration, then hands
   ownership back to UIPeek on exit.

   States (all dump-verified in object_dump_1.txt):
     SHPlayerController.IsRadarBriefindDisplayed()     -- briefing [engine typo]
     SHPlayerController.IsInGameMenuVisible()          -- pause menu
     SHPlayerController.IsPostLoadingScreenDisplayed() -- loading screen
     bShowMouseCursor                                  -- start screen / catch-all

-----------------------------------------------------------------
HOW THE OVERRIDE REACHES UIPeek -- READ THIS

Two channels, because they have different reach:

  (a) UI_Distance panel  -- handled here, no UIPeek edit needed.
      ZZ_ load order puts this callback AFTER UIPeek's in the same
      tick, so our per-tick write is the last one before the frame
      composes and wins over UIPeek's 0.25s re-assert.

  (b) Game HUD WidgetComponents -- CANNOT be done from here safely.
      UIPeek caches origVis/hidden/widgetId per component. A second
      script calling SetVisibility on those same components would race
      that cache and could restore the wrong value, or fight the 0.5s
      sweep. So we publish a global flag and let UIPeek own the call.

      ONE-LINE EDIT REQUIRED IN UIPeek.lua:

          local engaged = thumbrest_held() or rb_held()

      becomes:

          local engaged = thumbrest_held() or rb_held()
                          or (_G.UIPEEK_FORCE_VISIBLE == true)

      Without that edit the panel still behaves, but the game HUD
      widgets stay hidden during menus.

-----------------------------------------------------------------
We never write the HIDDEN distance ourselves. On exit we just drop the
flag and stop writing; UIPeek re-asserts its own state within
REASSERT_INTERVAL (0.25s). That avoids stomping an in-progress
thumbrest peek at the moment a menu closes.

VISIBLE_DISTANCE below MUST match UIPeek's VISIBLE_DISTANCE.
set_mod_value takes STRINGS. Setter = dot syntax, getter = colon.

PLACEMENT: scripts\ root. ZZ_ prefix is load-order-critical (see above).
--]]

local api = uevr.api
local vr  = uevr.params.vr
local log = uevr.params.functions

------------------------------------------------------------------
-- CONFIG
------------------------------------------------------------------
local DEBUG_LOG        = false      -- disable once confirmed

-- Perspective
local FIX_PERSPECTIVE  = true      -- DecoupledPitch toggle during briefing
local USE_UI_ADJUST    = true      -- also toggle VR_DecoupledPitchUIAdjust
local RECENTER_ON_OPEN = false     -- try true if map is framed but off-center

-- UI override
local FORCE_UI_IN_MENUS = true
local VISIBLE_DISTANCE  = "2.875000"  -- STRING. must match UIPeek.
local MANAGE_UI_PANEL   = true        -- direct UI_Distance write (channel a)

-- Which states force the UI visible
local ON_BRIEFING  = true
local ON_PAUSE     = true
local ON_LOADING   = true
local ON_CURSOR    = true   -- start screen / any cursor menu

------------------------------------------------------------------

local function LOG(s)
    if not DEBUG_LOG then return end
    local ok = pcall(function() log.log_info("[RBPersp] " .. s) end)
    if not ok then print("[RBPersp] " .. s) end
end

local function get_pc()
    local pc = nil
    pcall(function() pc = api:get_player_controller(0) end)
    return pc
end

-- Guarded reflected bool call. Returns true/false, or nil if unreadable.
local function call_bool(pc, fname)
    if pc == nil then return nil end
    local ok, v = pcall(function() return pc[fname](pc) end)
    if ok then return (v == true) end
    return nil
end

local function read_bool_prop(pc, pname)
    if pc == nil then return nil end
    local ok, v = pcall(function() return pc[pname] end)
    if ok then return (v == true) end
    return nil
end

------------------------------------------------------------------
-- State detection
------------------------------------------------------------------
local function briefing_open(pc)
    return call_bool(pc, "IsRadarBriefindDisplayed")   -- engine typo: "Briefind"
end

local function menu_open(pc)
    return call_bool(pc, "IsInGameMenuVisible")
end

local function loading_shown(pc)
    return call_bool(pc, "IsPostLoadingScreenDisplayed")
end

local function cursor_shown(pc)
    return read_bool_prop(pc, "bShowMouseCursor")
end

-- Returns overall override + a short label for logging.
local function ui_should_be_visible(pc)
    if not FORCE_UI_IN_MENUS then return false, "" end
    local parts = {}
    if ON_BRIEFING and briefing_open(pc) == true then parts[#parts+1] = "briefing" end
    if ON_PAUSE    and menu_open(pc)     == true then parts[#parts+1] = "pause"    end
    if ON_LOADING  and loading_shown(pc) == true then parts[#parts+1] = "loading"  end
    if ON_CURSOR   and cursor_shown(pc)  == true then parts[#parts+1] = "cursor"   end
    if #parts == 0 then return false, "" end
    return true, table.concat(parts, "+")
end

------------------------------------------------------------------
-- Perspective (DecoupledPitch)
------------------------------------------------------------------
local function set_decoupled(enabled_bool)
    local v = enabled_bool and "true" or "false"
    pcall(function() vr.set_mod_value("VR_DecoupledPitch", v) end)
    if USE_UI_ADJUST then
        -- key may not exist on this build; pcall keeps it harmless
        pcall(function() vr.set_mod_value("VR_DecoupledPitchUIAdjust", v) end)
    end
end

-- One-shot on first open: is the view target actually the radar camera?
-- Decides whether DecoupledPitch is even the right lever.
local probed = false
local function probe_view_target(pc)
    if probed then return end
    probed = true

    local vt = nil
    pcall(function() vt = pc:GetViewTarget() end)

    local radar = nil
    pcall(function()
        local cls = api:find_uobject("Class /Script/SpaceHulkGame.SHRadar")
        if cls then radar = UEVR_UObjectHook.get_first_object_by_class(cls) end
    end)

    if radar == nil then
        LOG("SHRadar not found; ViewTarget present = " .. tostring(vt ~= nil))
        return
    end

    local cam, camOrtho, horiz = nil, nil, nil
    pcall(function() cam      = radar.Cam end)
    pcall(function() camOrtho = radar.CamOrtho end)
    pcall(function() horiz    = radar.bIsHorizontal end)

    local isCam   = (vt ~= nil) and (vt == cam)
    local isOrtho = (vt ~= nil) and (vt == camOrtho)

    LOG(string.format("bIsHorizontal=%s | VT==Cam:%s VT==CamOrtho:%s",
        tostring(horiz), tostring(isCam), tostring(isOrtho)))
    if isCam or isOrtho then
        LOG("view target IS radar cam -> DecoupledPitch is the right lever")
    else
        LOG("view target is NOT radar cam -> perspective fix likely won't apply;")
        LOG("the table is just positioned low. Try flipping bIsHorizontal.")
    end
end

------------------------------------------------------------------
-- Tick
------------------------------------------------------------------
local last_brief = nil
local last_ui    = nil

_G.UIPEEK_FORCE_VISIBLE = false   -- published for UIPeek (channel b)

uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
    local pc = get_pc()
    if pc == nil then return end

    ----------------------------------------------------------------
    -- 1. UI override
    ----------------------------------------------------------------
    local wantUI, why = ui_should_be_visible(pc)

    _G.UIPEEK_FORCE_VISIBLE = wantUI

    if wantUI ~= last_ui then
        if wantUI then
            LOG("UI FORCED VISIBLE (" .. why .. ")")
        else
            -- Do NOT write the hidden distance. Dropping the flag and
            -- going quiet lets UIPeek reclaim within its re-assert
            -- interval without stomping an active thumbrest peek.
            LOG("UI override released -> UIPeek resumes")
        end
        last_ui = wantUI
    end

    -- Re-assert every tick while overriding so UIPeek's periodic
    -- re-pin cannot collapse the panel mid-menu.
    if wantUI and MANAGE_UI_PANEL then
        pcall(function() vr.set_mod_value("UI_Distance", VISIBLE_DISTANCE) end)
    end

    ----------------------------------------------------------------
    -- 2. Perspective
    ----------------------------------------------------------------
    if not FIX_PERSPECTIVE then return end

    local open = briefing_open(pc)
    if open == nil then return end

    if open ~= last_brief then
        if open then
            LOG("briefing OPEN -> DecoupledPitch OFF")
            probe_view_target(pc)
            if RECENTER_ON_OPEN then pcall(function() vr.recenter_view() end) end
        else
            LOG("briefing CLOSED -> DecoupledPitch restored")
            set_decoupled(true)
        end
        last_brief = open
    end

    -- Re-assert while open: MainHandler.MenuStatus writes
    -- VR_DecoupledPitch = "true" every tick whenever the cursor is off,
    -- which it is for the whole briefing. Our later write wins.
    if open then
        set_decoupled(false)
    end
end)

LOG("v2 loaded.")