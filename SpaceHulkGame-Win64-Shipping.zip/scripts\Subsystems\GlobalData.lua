require(".\\Subsystems\\HelperFunctions")





 --Trackers
 hmd_component = nil
 right_hand_component= nil
 left_hand_component=nil 
 right_hand_handler = nil
 left_hand_handler = nil
 
 
  --Collisions:
 BoxCompLH=nil
 BoxCompRH=nil
 BoxCompHmdChestRight	=nil
 BoxCompHmdRightHip     =nil
 BoxCompHmdLeftHip      =nil
 BoxCompHmdRightShoulder=nil
 BoxCompHmdLeftShoulder=nil
 MagBox=nil
 
 --ControlInput
  ThumbLX   = 0
 ThumbLY   = 0
 ThumbRX   = 0
 ThumbRY   = 0
 LTrigger  = 0
 RTrigger  = 0
 rShoulder = false
 lShoulder = false
 lThumb    = false
 rThumb    = false
 Abutton = false
 Bbutton = false
 Xbutton = false
 Ybutton = false
 DPAD_Up   = false
 DPAD_Right= false
 DPAD_Left = false
 DPAD_Down = false
 StickR=UEVR_Vector2f.new()
 SelectButton=false
 AbsThumbFactor = 0
 canPressA=true
 --StaticClasses
 game_engine_class = find_required_object("Class /Script/Engine.GameEngine")
 kismet_string_library = find_static_class("Class /Script/Engine.KismetStringLibrary")
 kismet_math_library = find_static_class("Class /Script/Engine.KismetMathLibrary")
 kismet_system_library = find_static_class("Class /Script/Engine.KismetSystemLibrary")
 Statics = find_static_class("Class /Script/Engine.GameplayStatics")
 --Classes
 VHitBoxClass= find_required_object("Class /Script/Engine.BoxComponent")
 hitresult_c = find_required_object("ScriptStruct /Script/Engine.HitResult") 
 CameraManager_C = find_required_object("Class /Script/Engine.PlayerCameraManager")
 Key_C= find_required_object("ScriptStruct /Script/InputCore.Key")
 PhysicsComp_C= find_required_object("Class /Script/Engine.PhysicsHandleComponent")
 PhysicsConstraint_C = find_required_object("Class /Script/Engine.PhysicsConstraintComponent")
 ftransform_c = find_required_object("ScriptStruct /Script/CoreUObject.Transform")
  Rotator_c = find_required_object("ScriptStruct /Script/CoreUObject.Rotator")
 Vector_C = find_required_object("ScriptStruct /Script/CoreUObject.Vector")
 actor_c = find_required_object("Class /Script/Engine.Actor")
 --TempStructs:
 TempKey = StructObject.new(Key_C)
 Temphitresult = StructObject.new(hitresult_c)
 
 --Globals:
 CurrentEquipmentArray = {}

 LeftController=uevr.params.vr.get_left_joystick_source()
 StickFactor = 0
 gDelta = 0
 isMenu=false
 isSprinting=false

 CameraManager=UEVR_UObjectHook.get_first_object_by_class(CameraManager_C)
DecoupledYawCurrentRot = 0


 WpnLocationUpdate=false
 
 isThumbMotion=false

 CurrentWeaponMesh=nil
  
 FireWeapon=true
 world= nil
 isCinematic=false

 unpressShoulder=false

 wasRecentered=false
 isSprinting = false
InitCount =0
 Init= false
 TrueMesh= nil
 neededPitch = 0
-- global functions:
function GetHandDistance()
	if right_hand_component == nil or left_hand_component==nil then return 0 end
	local rightLoc= right_hand_component:K2_GetComponentLocation()
	local leftLoc = left_hand_component:K2_GetComponentLocation()
	local Dist = kismet_math_library:Vector_Distance(rightLoc,leftLoc)
	return Dist
end

