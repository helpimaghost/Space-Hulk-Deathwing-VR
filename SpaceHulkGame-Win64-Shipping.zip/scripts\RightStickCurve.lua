--[[
================================================================================
  RightStickCurve.lua  (v3 - RB bypass)
  Standalone right-stick turn shaping for UEVR (UE4.14 safe)

  v3 adds: shaping is suspended while RB is held, so the radial command wheel
  receives the raw, unmodified stick.

  WHY THIS MATTERS:
    The wheel picks a sector from atan2(RY, RX). This script shapes RX but not
    RY, so at MAX_RATE = 0.35 a full-right push reads ~16793 while full-up reads
    32767 - biasing every selection angle toward vertical by roughly 30 degrees.
    Left/right sectors become hard to hit and diagonals land in the wrong wedge.
    The bypass therefore suspends BOTH axes, not just the turn axis.

  Chain (normal operation):
    stick -> our deadzone -> our curve -> our ramp -> deadzone compensation
          -> game deadzone strips it back off -> game applies sensitivity

  Dependencies: none. Registers only on_xinput_get_state and on_pre_engine_tick,
  both additively. Does not require libs/uevr_utils or libs/controllers.

  NOTE: UEVR's VR_SnapTurn must be OFF. Snap turn reads the runtime joystick
  axis directly and bypasses XInput entirely.
================================================================================
]]--

local api = uevr.api

-- ========================= STEP 1: CALIBRATION ==============================
-- Set CALIBRATE = true, load in, then:
--   1. Stand still with a clear view of a wall or landmark.
--   2. Hold the right stick fully RIGHT and keep holding.
--   3. Output ramps slowly upward from zero. The instant you see the view
--      begin to rotate, RELEASE the stick.
--   4. Read the last line of log.txt: "CALIBRATION RESULT deadzone = X.XXX"
--   5. Put that number in GAME_DEADZONE below, set CALIBRATE = false.

local CALIBRATE        = false
local CAL_SWEEP_RATE   = 0.02   -- output units per second during the sweep

-- ========================= STEP 2: GAME PROPERTIES ==========================
-- The game's own axis deadzone. Confirmed working at the UE4 default of 0.25.
local GAME_DEADZONE    = 0.25

-- The game's own axis exponent. UE4 default is 1.0 (linear).
local GAME_EXPONENT    = 1.00

-- ========================= STEP 3: FEEL ======================================

-- Maximum turn rate as a fraction of the game's full turn speed (0.0 - 1.0).
-- THIS is your sensitivity knob.
local MAX_RATE         = 0.35

-- Our own inner deadzone, fraction of physical stick throw.
local DEADZONE         = 0.03

-- Outer saturation: deflection past this counts as full.
local SATURATION       = 0.95

-- Response curve exponent. 1.0 = linear, 1.7 = D2-ish, 2.2+ = very fine centre.
local EXPONENT         = 1.70

-- ---- Turn acceleration (the D2 signature) ----
local RAMP_ENABLED     = true
local RAMP_START       = 0.55   -- multiplier at the instant you push the stick
local RAMP_TIME        = 0.28   -- seconds from RAMP_START to full rate
local RAMP_THRESHOLD   = 0.70   -- normalized deflection required to accelerate
local RAMP_RELEASE     = 0.12   -- seconds to decay back once below threshold

-- ========================= STEP 4: BYPASS ====================================
-- Suspend all shaping while a button is held, so radial menus and any other
-- direction-picking UI receive the raw stick.

local BYPASS_ENABLED   = true
local BYPASS_BUTTON    = 0x0200  -- XINPUT_GAMEPAD_RIGHT_SHOULDER (RB)
local BYPASS_GRACE     = 0.20    -- seconds of raw passthrough after release,
                                 -- so the wheel's close animation is not fought

-- ---- Vertical axis ----
-- Off by default. With VR_DecoupledPitch enabled, pitch comes from the HMD.
local SHAPE_VERTICAL   = false
local VERT_MAX_RATE    = 0.35

-- Skip all shaping while the mouse cursor is up (menus, map screens).
local RESPECT_CURSOR   = true

-- Log shaped output four times a second while turning.
local DEBUG_LOG        = false

-- ============================================================================

local AXIS_MAX = 32767
local AXIS_MIN = -32768

local now      = 0.0
local lastNow  = 0.0
local rampMul  = RAMP_START
local lastSign = 0
local logAccum = 0.0

local bypassTimer = 0.0
local bypassWas   = false

local calLevel   = 0.0
local calActive  = false

local function logInfo(msg)
    pcall(function() uevr.params.functions.log_info(msg) end)
end

uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
    if delta ~= nil then now = now + delta end
end)

local function cursorShown()
    local ok, flag = pcall(function()
        local pc = api:get_player_controller(0)
        if pc == nil then return false end
        return pc.bShowMouseCursor == true
    end)
    return ok and (flag == true)
end

local function buttonHeld(state, mask)
    local w = state.Gamepad.wButtons
    if w == nil then return false end
    return (w & mask) ~= 0
end

local function toAxis(sign, magnitude)
    local out = math.floor((sign * magnitude * AXIS_MAX) + 0.5)
    if out > AXIS_MAX then out = AXIS_MAX end
    if out < AXIS_MIN then out = AXIS_MIN end
    return out
end

-- Returns sign (-1, 0, 1) and normalized curved magnitude (0.0 - 1.0)
local function shapeAxis(raw)
    if raw == nil then return 0, 0 end
    local mag = math.abs(raw) / AXIS_MAX
    if mag <= DEADZONE then return 0, 0 end

    local span = SATURATION - DEADZONE
    if span <= 0 then span = 0.0001 end

    local n = (mag - DEADZONE) / span
    if n > 1.0 then n = 1.0 end

    local sign = (raw > 0) and 1 or -1
    return sign, n ^ EXPONENT
end

-- Convert a desired turn rate (0-1, fraction of the game's max) into the raw
-- axis magnitude required to survive the game's deadzone and exponent intact.
local function compensate(rate)
    if rate <= 0 then return GAME_DEADZONE end
    local inv = rate
    if GAME_EXPONENT ~= 1.0 and GAME_EXPONENT > 0 then
        inv = rate ^ (1.0 / GAME_EXPONENT)
    end
    local mag = GAME_DEADZONE + (inv * (1.0 - GAME_DEADZONE))
    if mag > 1.0 then mag = 1.0 end
    return mag
end

local function resetShapingState()
    rampMul  = RAMP_START
    lastSign = 0
end

local function updateRamp(sign, n, dt)
    if not RAMP_ENABLED then return 1.0 end

    if sign == 0 or sign ~= lastSign then
        rampMul = RAMP_START
    elseif n >= RAMP_THRESHOLD then
        if RAMP_TIME > 0 then
            rampMul = rampMul + dt * ((1.0 - RAMP_START) / RAMP_TIME)
        else
            rampMul = 1.0
        end
        if rampMul > 1.0 then rampMul = 1.0 end
    else
        if RAMP_RELEASE > 0 then
            rampMul = rampMul - dt * ((1.0 - RAMP_START) / RAMP_RELEASE)
        else
            rampMul = RAMP_START
        end
        if rampMul < RAMP_START then rampMul = RAMP_START end
    end

    lastSign = sign
    return rampMul
end

-- Sweep output upward while the stick is held, report the level on release.
local function runCalibration(state, dt)
    local rx  = state.Gamepad.sThumbRX
    local mag = math.abs(rx) / AXIS_MAX

    if mag > 0.5 then
        if not calActive then
            calActive = true
            calLevel  = 0.0
            logInfo("[RightStickCurve] CALIBRATION started - release when the view begins to rotate")
        end
        calLevel = calLevel + (dt * CAL_SWEEP_RATE)
        if calLevel > 1.0 then calLevel = 1.0 end

        logAccum = logAccum + dt
        if logAccum >= 0.5 then
            logAccum = 0
            logInfo(string.format("[RightStickCurve] sweep level = %.3f", calLevel))
        end

        local sign = (rx > 0) and 1 or -1
        state.Gamepad.sThumbRX = toAxis(sign, calLevel)
    else
        if calActive then
            calActive = false
            logInfo(string.format("[RightStickCurve] CALIBRATION RESULT deadzone = %.3f", calLevel))
            calLevel = 0.0
        end
        state.Gamepad.sThumbRX = 0
    end
end

uevr.sdk.callbacks.on_xinput_get_state(function(retval, user_index, state)
    if state == nil or state.Gamepad == nil then return end

    local dt = now - lastNow
    lastNow = now
    if dt < 0 then dt = 0 end
    if dt > 0.25 then dt = 0.25 end   -- clamp across hitches and loading

    if RESPECT_CURSOR and cursorShown() then
        resetShapingState()
        bypassTimer = 0.0
        bypassWas   = false
        return
    end

    -- ---- Bypass: hand the raw stick straight through ----
    if BYPASS_ENABLED then
        if buttonHeld(state, BYPASS_BUTTON) then
            bypassTimer = BYPASS_GRACE
        elseif bypassTimer > 0 then
            bypassTimer = bypassTimer - dt
            if bypassTimer < 0 then bypassTimer = 0 end
        end

        if bypassTimer > 0 then
            if not bypassWas then
                bypassWas = true
                if DEBUG_LOG then logInfo("[RightStickCurve] bypass ON") end
            end
            -- Reset continuously so shaping resumes from the slow end of the
            -- ramp rather than bursting the moment the wheel closes.
            resetShapingState()
            return
        elseif bypassWas then
            bypassWas = false
            if DEBUG_LOG then logInfo("[RightStickCurve] bypass OFF") end
        end
    end

    if CALIBRATE then
        runCalibration(state, dt)
        return
    end

    -- Horizontal (turn)
    local sign, n = shapeAxis(state.Gamepad.sThumbRX)
    local mul = updateRamp(sign, n, dt)

    if sign == 0 then
        state.Gamepad.sThumbRX = 0
    else
        local rate = n * mul * MAX_RATE
        state.Gamepad.sThumbRX = toAxis(sign, compensate(rate))
    end

    -- Vertical (pitch), optional, no acceleration
    if SHAPE_VERTICAL then
        local vSign, vN = shapeAxis(state.Gamepad.sThumbRY)
        if vSign == 0 then
            state.Gamepad.sThumbRY = 0
        else
            state.Gamepad.sThumbRY = toAxis(vSign, compensate(vN * VERT_MAX_RATE))
        end
    end

    if DEBUG_LOG then
        logAccum = logAccum + dt
        if logAccum >= 0.25 and sign ~= 0 then
            logAccum = 0
            logInfo(string.format(
                "[RightStickCurve] n=%.3f ramp=%.3f rate=%.3f axis=%d",
                n, mul, n * mul * MAX_RATE, state.Gamepad.sThumbRX))
        end
    end
end)