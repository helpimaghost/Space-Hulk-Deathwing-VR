--local controllers = require('libs/controllers')
--require(".\\Config\\CONFIG")
require(".\\Subsystems\\GlobalData")
--require(".\\Subsystems\\GlobalCustomData")
require(".\\Subsystems\\HelperFunctions")
	




local CamAngle=RightRotator
local AttackDelta=0
local HandVector= Vector3f.new(0.0,0.0,0.0)
local HmdVector = Vector3f.new(0.0,0.0,0.0)
local VecAlpha  = Vector3f.new(0,0,0)
local Alpha  	= nil
local AlphaDiff =0
local LastState= isBow
local ConditionChagned=false
local isMenuEnter=false
local YawLast=0
local hitresult = {}--StructObject.new(hitresult_c)
local LeftRightScaleFactor		=0
local ForwardBackwardScaleFactor=0
	
local DecoupledYawCurrentRot = 0
local RXState=0
local SnapAngle

--local neededPitch= 0--hmd_component:K2_GetComponentRotation().X
local neededYaw2 = 0
local CurrentPitch = 0--player.ControlRotation.X
local DiffPitch = 0--(neededPitch - CurrentPitch)
--local Target = KismetMathLib:Add_VectorVector(hmd_component:K2_GetComponentRotation(), hmd_component:GetForwardVector()*500)
local rotdelta =0
local CamDelta=20
	local rotationNew =0

uevr.sdk.callbacks.on_post_engine_tick(
function(engine, delta)
local pawn = api:get_local_pawn(0)
local player =api:get_player_controller(0)
--print(DecoupledYawCurrentRot)
--print(ThumbRX)
if pawn~=nil  then
	
	if pawn.RArm then
		UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RArm):set_hand(1)
		UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RArm):set_rotation_offset(Vector3d.new((neededPitch+5)/180*math.pi,-5.1/180*math.pi,0))
		UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RArm):set_location_offset(Vector3d.new(40,160+neededPitch/45*30,-50+math.abs(neededPitch/45)*30))
		UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RArm):set_permanent(true)
		
		
		
		
		
		--UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LArm):set_hand(0)
		--UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LArm):set_rotation_offset(Vector3d.new(neededPitch/180*math.pi,0,0))
		--UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LArm):set_location_offset(Vector3d.new(-40,160+neededPitch/45*30,-50+math.abs(neededPitch/45)*30))
		--UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LArm):set_permanent(true)
		
		
		if pawn.RightWeapon.RootComponent.AttachParent~= pawn.RArm or not Init then
			Init=true
			
			
			--pawn.Torso.bForceRefpose= false
			
			--UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RightWeapon.RootComponent):set_rotation_offset(Vector3d.new(0,math.pi/2,0))
			--UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RArm):set_location_offset(Vector3d.new(60,150,0))
			--UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RightWeapon.RootComponent):set_permanent(false)
			--pawn.RightWeapon.RootComponent:K2_AttachToComponent(pawn.RArm,"RGun",2,2,true)
		else
			--UEVR_UObjectHook.remove_motion_controller_state(pawn.RightWeapon.RootComponent)
		end
		
		
		if Init then
			InitCount = InitCount+ delta
			UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.Torso):set_hand(2)
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.Torso):set_rotation_offset(Vector3d.new(-0.25,-0.20,0.076))
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.Torso):set_location_offset(Vector3d.new(4,218,-9))
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.Torso):set_permanent(true)

			if pawn.LShoulderPad and pawn.RShoulderPad then
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LShoulderPad):set_hand(2)
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LShoulderPad):set_rotation_offset(Vector3d.new(0,0,0))
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LShoulderPad):set_location_offset(Vector3d.new(0,0,0))
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.LShoulderPad):set_permanent(true)

				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RShoulderPad):set_hand(2)
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RShoulderPad):set_rotation_offset(Vector3d.new(0,0,0))
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RShoulderPad):set_location_offset(Vector3d.new(0,0,0))
				UEVR_UObjectHook.get_or_add_motion_controller_state(pawn.RShoulderPad):set_permanent(true)
			end
			--if InitCount> 10 then
			--	Init=false
			--	InitCount=0
				--if pawn.Torso.bForceRefpose == false then
					pawn.Torso.bForceRefpose= true
					
				--end
			--end
		end
					
		--pawn.CameraEyes:K2_AttachToComponent(pawn.RightWeapon,"RGun",2,2,0,false)
		pawn.RightWeapon.RootComponent:K2_AttachToComponent(pawn.RArm,"RGun",0,0,0,false)
		
	end
	--if not rShoulder then
		--pawn.DesiredControllerPitch=neededPitch
	--else
		--	pawn.DesiredControllerPitch= 0
			
		print(neededPitch)	
			
			
			
			
	--end
	--if hmd_component~=nil then	
		--neededPitch= right_hand_component:K2_GetComponentRotation().X
		--CurrentPitch = player.ControlRotation.X
		--DiffPitch = (neededPitch - CurrentPitch)		
		--rotdelta = neededYaw- player.ControlRotation.Yaw
		
		
		
		
		--local Target = KismetMathLib:Add_VectorVector(hmd_component:K2_GetComponentRotation(), hmd_component:GetForwardVector()*500)
		
	
		--if rotdelta > 180 then
		--	rotdelta = rotdelta - 360
		--elseif rotdelta < -180 then
		--	rotdelta = rotdelta + 360
		--end
		
		--print(rotdelta)
		
		--if pawn~=nil then
		--	if DiffPitch>0 then
		--		pawn:InpAxisEvt_LookUp_K2Node_InputAxisEvent_1(-math.abs(DiffPitch)*delta)
		--	elseif DiffPitch<-0 then
		--		pawn:InpAxisEvt_LookUp_K2Node_InputAxisEvent_1(math.abs(DiffPitch)*delta)
		--	end
		--	if rotdelta>0 then
		--		pawn:InpAxisEvt_Turn_K2Node_InputAxisEvent_0(math.abs(rotdelta)*delta)
		--	elseif rotdelta<-0 then
		--		pawn:InpAxisEvt_Turn_K2Node_InputAxisEvent_0(-math.abs(rotdelta)*delta)
		--	end
		--end
			
			
			
			--HmdVector=hmd_component:GetForwardVector()
		--	HandVector= right_hand_component:GetForwardVector()
			
		--	VecAlpha = (HandVector.x - HmdVector.x, HandVector.y - HmdVector.y, HandVector.z - HmdVector.z)
						--		local VecAlphaX= HandVector.x - HmdVector.x
						--		local VecAlphaY= HandVector.y - HmdVector.y
						--		local Alpha1
						--		local Alpha2
						--		if HandVector.x >=0 and HandVector.y>=0 then	
						--		Alpha1 =math.pi/2-math.asin( HandVector.x/ math.sqrt(HandVector.y^2+HandVector.x^2))
						--		--print("Quad1")
						--		elseif HandVector.x <0 and HandVector.y>=0 then
						--		--print("Quad2")
						--		Alpha1 =math.pi/2-math.asin( HandVector.x/ math.sqrt(HandVector.y^2+HandVector.x^2))
						--		elseif HandVector.x <0 and HandVector.y<0 then
						--		--print("Quad3")
						--		Alpha1 =math.pi+math.pi/2+math.asin( HandVector.x/ math.sqrt(HandVector.y^2+HandVector.x^2))
						--		elseif HandVector.x >=0 and HandVector.y<0 then
						--		--print("Quad4")
						--		Alpha1 =3/2*math.pi+math.asin( HandVector.x/ math.sqrt(HandVector.y^2+HandVector.x^2))
						--		end
						--		
						--		if HmdVector.x >=0 and HmdVector.y>=0 then	
						--		Alpha2 =math.pi/2-math.asin( HmdVector.x/ math.sqrt(HmdVector.y^2+HmdVector.x^2))
						--		--print("Quad1")
						--		elseif HmdVector.x <0 and HmdVector.y>=0 then
						--		--print("Quad2")
						--		Alpha2 =math.pi/2-math.asin( HmdVector.x/ math.sqrt(HmdVector.y^2+HmdVector.x^2))
						--		elseif HmdVector.x <0 and HmdVector.y<0 then
						--		--print("Quad3")
						--		Alpha2 =math.pi+math.pi/2+math.asin( HmdVector.x/ math.sqrt(HmdVector.y^2+HmdVector.x^2))
						--		elseif HmdVector.x >=0 and HmdVector.y<0 then
						--		--print("Quad4")
						--		Alpha2 =3/2*math.pi+math.asin( HmdVector.x/ math.sqrt(HmdVector.y^2+HmdVector.x^2))
						--		end
						--		
						--		
						--		AlphaDiff= Alpha2-Alpha1
						--		if isBow and RTrigger ~= 0 then
						--			AlphaDiff=AlphaDiff-math.pi*20/180
						--		end
			
			
			
	
	
	--end
end



 




--Read Gamepad stick input for rotation compensation
	--if HeadBasedMovement   then
	
	
	
	
	
	
	--end



	SnapAngle = PositiveIntegerMask(uevr.params.vr:get_mod_value("VR_SnapturnTurnAngle"))
		if SnapTurn and not isMenu then
			if StickR.x >0.2 and RXState ==0  then
				pawn.Controller.ControlRotation.Yaw =DecoupledYawCurrentRot + SnapAngle
				RXState=1
			elseif StickR.x <-0.2 and RXState ==0   then
				pawn.Controller.ControlRotation.Yaw =DecoupledYawCurrentRot - SnapAngle
				RXState=1
			elseif StickR.x <= 0.200 and StickR.x >=-0.200  then
				RXState=0
			end
	
		
		else
			
			SmoothTurnRate = PositiveIntegerMask(uevr.params.vr:get_mod_value("VR_SnapturnTurnAngle"))/90
		
		
			local rate = StickR.x
						rate =  rate*rate*rate
			if StickR.x >0.1 and not isMenu and not TactiNavVisible then
				DecoupledYawCurrentRot =DecoupledYawCurrentRot + SmoothTurnRate * rate
				
			elseif StickR.x <-0.1 and not isMenu and not TactiNavVisible  then
				DecoupledYawCurrentRot =DecoupledYawCurrentRot + SmoothTurnRate * rate
			
			end
		end
	
end)



local PreRot
local DiffRot
local DecoupledYawCurrentRotLast=0
uevr.sdk.callbacks.on_pre_calculate_stereo_view_offset(function(device, view_index, world_to_meters, position, rotation, is_double)

local pawn = api:get_local_pawn(0)	
	--DecoupledYawCurrentRot = pawn.Controller.ControlRotation.Yaw
	--rotation.y = DecoupledYawCurrentRot
	if rotation.x~=0 then
		neededPitch = rotation.x
		
	
	end
	
	
	
	
	
	
	
	
	--vr.recenter_view()

if pawn~=nil and string.find(pawn:get_full_name(), "Player") then
	--position.z = pawn:K2_GetActorLocation().z+88
	--position.x = pawn:K2_GetActorLocation().x
	--position.y = pawn:K2_GetActorLocation().y
end

end)

uevr.sdk.callbacks.on_post_calculate_stereo_view_offset(function(device, view_index, world_to_meters, position, rotation, is_double)
	--print(DecoupledYawCurrentRot)
local pawn=api:get_local_pawn(0)


	DecoupledYawCurrentRotLast=rotation.y	

end)