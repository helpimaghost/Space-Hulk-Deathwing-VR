local uevrUtils = require('libs/uevr_utils')
local hands = require('libs/hands')
local controllers = require('libs/controllers')

function on_level_change(level)
	controllers.createController(0)
	controllers.createController(1)
	hands.reset()

	local paramsFile = 'hands_parameters' -- found in the [game profile]/data directory
	local configName = 'Main' -- the name you gave your config
	local animationName = '' -- the name you gave your animation
	hands.createFromConfig(paramsFile, configName, animationName)
end

--function on_xinput_get_state(retval, user_index, state)
--	if hands.exists() then
--		local isHoldingWeapon = false
--		local hand = Handed.Right
--		if not ReloadMontage then
--			hands.handleInput(state, isHoldingWeapon, hand)
--		else
--			hands.handleInput(state, isHoldingWeapon, hand,255,true)
--		end
--		if lShoulder then
--			hands.getHandComponent(Handed.Right)
--		end
--end		
		
--		if ReloadMontage  then
--			--InvisL=true
----MOVED TO ManReload.lua
--			--hands.getHandComponent(Handed.Right):SetVisibility(false)
--			--hands.getHandComponent(Handed.Left):SetVisibility(true)
--			--pawn.Mesh:HideBoneByName("clavicle_l")
--			LHandM:SetVisibility(true,true)
--		elseif not ReloadMontage and (lShoulder or MagCheckMontage) and not InvisL then
--			InvisL=true
--			hands.getHandComponent(Handed.Right):SetVisibility(false)
--		--	hands.getHandComponent(Handed.Left):SetVisibility(false)
--			hands.getHandComponent(Handed.Left):SetVisibility(false)
--			pawn.Mesh:UnHideBoneByName("clavicle_l")
--		elseif (not (lShoulder or MagCheckMontage) and not ReloadMontage and InvisL) or not Init then
--			hands.getHandComponent(Handed.Left):SetVisibility(true)
--			InvisL=false
--			pawn.Mesh:HideBoneByName("clavicle_l")
--			Init=true
--		end
--	end
--end